import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pkg from 'pg';
const { Pool } = pkg;

dotenv.config();

const app = express();
const PORT = process.env.API_PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_please_change_me';

// CORS
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173';
app.use(cors({ origin: CORS_ORIGIN, credentials: true }));

app.use(express.json());
app.use(cookieParser());

// Postgres
const DATABASE_URL = process.env.DATABASE_URL;
const pool = new Pool({
  connectionString: DATABASE_URL,
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

function signToken(user) {
  return jwt.sign({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '1d' });
}

function authMiddleware(req, res, next) {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Health
app.get('/api/health', (_, res) => res.json({ ok: true }));

// Bootstrap/register (only allowed if no users exist)
app.post('/api/auth/register', async (req, res) => {
  const { email, password, role = 'admin' } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  const { rows } = await pool.query('SELECT COUNT(*)::int AS count FROM users');
  if (rows[0].count > 0) return res.status(403).json({ error: 'Registration disabled (already initialized)' });
  const hash = await bcrypt.hash(password, 10);
  try {
    const ins = await pool.query(
      'INSERT INTO users (email, password_hash, role) VALUES ($1, $2, $3) RETURNING id, email, role, created_at',
      [email, hash, role]
    );
    res.json({ user: ins.rows[0] });
  } catch (e) {
    res.status(400).json({ error: 'Could not create user', detail: e.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email and password required' });
  const { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  const user = rows[0];
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = signToken(user);
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false, // set true behind HTTPS
    maxAge: 24 * 60 * 60 * 1000,
  });
  res.json({ ok: true });
});

// Logout
app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ ok: true });
});

// Me
app.get('/api/auth/me', authMiddleware, (req, res) => {
  res.json({ user: { email: req.user.email, role: req.user.role } });
});

// Example protected admin route
app.get('/api/admin/overview', authMiddleware, async (req, res) => {
  const { rows } = await pool.query('SELECT id, email, role, created_at FROM users ORDER BY id ASC');
  res.json({ users: rows });
});

app.listen(PORT, async () => {
  try {
    await initDb();
    console.log(`API running on :${PORT}`);
  } catch (e) {
    console.error('Failed DB init', e);
    process.exit(1);
  }
});
