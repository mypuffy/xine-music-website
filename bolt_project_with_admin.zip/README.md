# Xine Music Label Website

A modern, responsive website for Xine Music label built with React, TypeScript, and Tailwind CSS.

## Features

- 🎵 Modern music label website design with reverse proxy support
- 📱 Fully responsive across all devices
- 🎨 Beautiful dark theme with purple/blue accents
- ⚡ Fast performance with Vite
- 🔍 SEO optimized
- 🎯 Artist profiles and music releases
- 📰 News and updates section
- 📧 Contact forms for submissions
- 🔄 Reverse proxy for API integration
- 🛡️ Advanced security headers and rate limiting
- 📊 Comprehensive logging and monitoring

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Build Tool**: Vite
- **Routing**: React Router
- **Icons**: Lucide React
- **Web Server**: Caddy (production)

## Development

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Getting Started

1. Clone the repository
```bash
git clone <repository-url>
cd xine-music-website
```

2. Install dependencies
```bash
npm install
```

3. Start development server
```bash
npm run dev
```

4. Open http://localhost:5173 in your browser

### Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## Deployment with Caddy

### Option 1: Direct Caddy Installation

1. Install Caddy on your server
2. Build the project: `npm run build`
3. Copy the `dist` folder to your server
4. Update the `Caddyfile` with your domain name
5. Start Caddy: `caddy run`

### Option 2: Docker Compose

1. Build the project: `npm run build`
2. Copy environment variables: `cp .env.example .env`
3. Update the `.env` file with your configuration
4. Create the external network and volume:
```bash
docker network create xine-music
docker volume create caddy_data
```
5. Start with Docker Compose:
```bash
docker-compose up -d
```

### Caddy Configuration

The included `Caddyfile` for xine-music.de provides:

- ✅ Automatic HTTPS with Let's Encrypt
- ✅ SPA routing support (React Router)
- ✅ Reverse proxy for API endpoints (/api/*)
- ✅ Admin panel proxy (/admin/*)
- ✅ Gzip compression
- ✅ Security headers
- ✅ Static asset caching
- ✅ Error handling
- ✅ Access logging
- ✅ Rate limiting
- ✅ Health checks
- ✅ Development subdomain (dev.xine-music.de)
- ✅ www to non-www redirect

### Configuration Steps

1. The domain is already configured for `xine-music.de`
2. Update the email in the Caddyfile global options
3. Configure your environment variables in `.env`
4. Ensure your domain's DNS points to your server
5. Make sure ports 80, 443, and 2019 are open on your server
6. Caddy will automatically obtain SSL certificates from Let's Encrypt

### File Structure for Production

```
/your-server-path/
├── Caddyfile
├── dist/           # Built React app
├── backend/        # API backend (optional)
├── admin/          # Admin panel (optional)
├── .env            # Environment variables
├── docker-compose.yml (optional)
├── logs/           # Caddy access logs
└── database/       # Database initialization scripts
```

## API Integration

The reverse proxy is configured to handle:

- **API Endpoints**: `/api/*` → `localhost:3001`
- **Admin Panel**: `/admin/*` → `localhost:3002`
- **Static Files**: Everything else → React SPA

### Backend Requirements

Your backend should:
- Listen on port 3001 (configurable)
- Provide a health check endpoint at `/api/health`
- Handle CORS properly (or let Caddy handle it)
- Return JSON responses for API routes

### Example API Structure

```
/api/artists          # GET - List all artists
/api/artists/:id      # GET - Get specific artist
/api/releases         # GET - List all releases
/api/releases/:id     # GET - Get specific release
/api/news            # GET - List news articles
/api/contact         # POST - Submit contact form
/api/health          # GET - Health check
```

## Customization

### Updating Content

- **Artists**: Edit `src/pages/ArtistsPage.tsx` or connect to `/api/artists`
- **Releases**: Edit `src/pages/ReleasesPage.tsx` or connect to `/api/releases`
- **News**: Edit `src/pages/NewsPage.tsx` or connect to `/api/news`
- **About**: Edit `src/pages/AboutPage.tsx`
- **Contact**: Edit `src/pages/ContactPage.tsx` or connect to `/api/contact`

### Styling

- Colors and theme: `tailwind.config.js`
- Global styles: `src/index.css`
- Component styles: Individual component files

### Images

Replace the Pexels placeholder images with your own or serve them via API:
- Artist photos
- Album covers
- Studio photos
- Background images

## Monitoring and Maintenance

### Health Checks

- Caddy: `http://localhost:2019/metrics`
- Backend: `https://xine-music.de/api/health`
- Database: Configured in docker-compose

### Logs

- Access logs: `/var/log/caddy/xine-music-access.log`
- Error logs: Caddy's built-in error logging
- Application logs: Configure in your backend

### SSL Certificate

Caddy automatically manages SSL certificates from Let's Encrypt. Certificates are stored in the `caddy_data` volume and renewed automatically.

## Performance

The website is optimized for performance with:
- Code splitting
- Image optimization
- Gzip compression
- Browser caching
- CDN-ready static assets
- API response caching
- Minimal bundle size

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is licensed under the MIT License.