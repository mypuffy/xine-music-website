import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../services/api';

export default function LoginPage() {
  const [email, setEmail] = useState('admin@xine-music.de');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      navigate('/admin', { replace: true });
    } catch (e: any) {
      setError(e?.body?.error || 'Login fehlgeschlagen');
    }
  }

  return (
    <div className="max-w-md mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Login</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">E-Mail</label>
          <input value={email} onChange={e => setEmail(e.target.value)} className="w-full p-2 rounded bg-zinc-900 border border-zinc-700" />
        </div>
        <div>
          <label className="block mb-1">Passwort</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-2 rounded bg-zinc-900 border border-zinc-700" />
        </div>
        {error && <div className="text-red-400">{error}</div>}
        <button className="px-4 py-2 rounded bg-white text-black">Einloggen</button>
      </form>
    </div>
  );
}
