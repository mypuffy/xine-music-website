import React from 'react';
import { Calendar, User, ArrowRight, ChevronRight } from 'lucide-react';
import Button from '../components/ui/Button';

const NewsPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-black overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="relative z-10 max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Latest <span className="text-purple-500">News</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Stay up-to-date with the latest happenings at JSJ Music, from new releases to artist announcements.
            </p>
          </div>
        </div>
        <div className="absolute right-0 top-0 w-full h-full opacity-20">
          <div className="absolute right-[-10%] top-[10%] w-[600px] h-[600px] rounded-full bg-purple-700 blur-[120px]"></div>
          <div className="absolute right-[20%] bottom-[-10%] w-[500px] h-[500px] rounded-full bg-blue-700 blur-[120px]"></div>
        </div>
      </section>

      {/* Featured News */}
      <section className="py-16 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <div className="relative rounded-xl overflow-hidden">
            <div className="absolute inset-0 z-0">
              <img 
                src="https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg" 
                alt="New Studio Grand Opening" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/80 to-black/30"></div>
            </div>
            
            <div className="relative z-10 max-w-3xl p-8 md:p-12 lg:p-16">
              <span className="inline-block bg-purple-600 text-white text-xs font-medium px-3 py-1 rounded-full mb-4">
                Featured News
              </span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                JSJ Music Celebrates Grand Opening of New State-of-the-Art Studio
              </h2>
              <div className="flex items-center text-gray-400 mb-6">
                <Calendar className="h-4 w-4 mr-2" />
                <span className="text-sm">June 15, 2025</span>
                <span className="mx-2">•</span>
                <User className="h-4 w-4 mr-2" />
                <span className="text-sm">Jordan Smith</span>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                We're thrilled to announce the grand opening of our brand new recording studio in the heart of Los Angeles. This cutting-edge facility features state-of-the-art equipment, acoustically designed rooms, and a creative environment for our artists to thrive.
              </p>
              <Button to="/news/1" icon={<ArrowRight className="h-4 w-4" />}>
                Read Full Story
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* News Grid */}
      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {newsItems.map((item, index) => (
              <NewsCard key={index} item={item} />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Button variant="outline" icon={<ChevronRight className="h-4 w-4" />}>
              Load More News
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-20 bg-gradient-to-r from-purple-900 to-blue-900">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-white mb-6">
              Subscribe to Our Newsletter
            </h2>
            <p className="text-gray-200 mb-8">
              Stay updated with the latest news, releases, and exclusive content from JSJ Music. Be the first to know about new signings, upcoming events, and special announcements.
            </p>
            
            <form className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-white/50"
                required
              />
              <Button type="submit">
                Subscribe
              </Button>
            </form>
            
            <p className="text-gray-300 text-sm mt-4">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

type NewsItem = {
  title: string;
  excerpt: string;
  date: string;
  author: string;
  image: string;
  category: string;
};

const NewsCard = ({ item }: { item: NewsItem }) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden group hover:shadow-xl transition-all duration-300 hover:shadow-purple-900/20 flex flex-col h-full">
      <div className="relative overflow-hidden">
        <img 
          src={item.image} 
          alt={item.title} 
          className="w-full aspect-video object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-purple-600 text-white text-xs font-medium px-2 py-1 rounded">
            {item.category}
          </span>
        </div>
      </div>
      <div className="p-6 flex-grow flex flex-col">
        <h3 className="text-white font-bold text-xl mb-2 hover:text-purple-400 transition-colors">
          <a href="#">{item.title}</a>
        </h3>
        <div className="flex items-center text-gray-400 mb-4 text-sm">
          <Calendar className="h-3 w-3 mr-1" />
          <span>{item.date}</span>
          <span className="mx-2">•</span>
          <User className="h-3 w-3 mr-1" />
          <span>{item.author}</span>
        </div>
        <p className="text-gray-400 mb-6 text-sm leading-relaxed flex-grow">
          {item.excerpt}
        </p>
        <a 
          href="#" 
          className="text-purple-400 hover:text-purple-300 inline-flex items-center text-sm font-medium transition-colors mt-auto"
        >
          Read More
          <ArrowRight className="h-4 w-4 ml-1" />
        </a>
      </div>
    </div>
  );
};

const newsItems: NewsItem[] = [
  {
    title: "The Electric Collective Announces World Tour",
    excerpt: "Following the success of their latest album 'Neon Future,' The Electric Collective has announced a world tour spanning 15 countries and 30 cities.",
    date: "June 10, 2025",
    author: "Sarah Johnson",
    image: "https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg",
    category: "Tours"
  },
  {
    title: "Luna Nova's 'Midnight Dreams' Tops Electronic Charts",
    excerpt: "Luna Nova's new EP 'Midnight Dreams' has reached #1 on multiple electronic music charts, cementing her status as one of the genre's most innovative artists.",
    date: "May 20, 2025",
    author: "James Wilson",
    image: "https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg",
    category: "Releases"
  },
  {
    title: "JSJ Music Signs Rising Star Aria Waves",
    excerpt: "We're thrilled to welcome ambient music producer Aria Waves to the JSJ Music family. Her unique approach to soundscapes has already garnered critical acclaim.",
    date: "May 5, 2025",
    author: "Jordan Smith",
    image: "https://images.pexels.com/photos/1321909/pexels-photo-1321909.jpeg",
    category: "Artists"
  },
  {
    title: "Behind the Scenes: The Making of 'Quantum Fields'",
    excerpt: "Go behind the scenes with experimental duo Quantum Fields as they discuss the creative process behind their groundbreaking new EP.",
    date: "April 22, 2025",
    author: "Sarah Johnson",
    image: "https://images.pexels.com/photos/1694900/pexels-photo-1694900.jpeg",
    category: "Features"
  },
  {
    title: "JSJ Music Artists Featured in Major Film Soundtrack",
    excerpt: "Multiple JSJ Music artists have contributed original compositions to the soundtrack of the upcoming sci-fi blockbuster 'Ethereal Horizons.'",
    date: "April 8, 2025",
    author: "James Wilson",
    image: "https://images.pexels.com/photos/2114365/pexels-photo-2114365.jpeg",
    category: "Partnerships"
  },
  {
    title: "Skyler James Collaborates with Symphony Orchestra",
    excerpt: "In a groundbreaking fusion of indie and classical music, Skyler James teams up with the Los Angeles Philharmonic for a special performance.",
    date: "March 27, 2025",
    author: "Jordan Smith",
    image: "https://images.pexels.com/photos/1540406/pexels-photo-1540406.jpeg",
    category: "Events"
  }
];

export default NewsPage;