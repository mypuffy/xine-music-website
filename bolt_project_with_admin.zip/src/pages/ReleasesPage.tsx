import React, { useState } from 'react';
import { Play, Calendar, Clock, ExternalLink, Music, Disc, Filter } from 'lucide-react';
import Button from '../components/ui/Button';

const ReleasesPage = () => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [activeTypeFilter, setActiveTypeFilter] = useState<string>('all');
  const [showFilters, setShowFilters] = useState<boolean>(false);
  
  const handleCategoryFilter = (category: string) => {
    setActiveCategoryFilter(category);
  };
  
  const handleTypeFilter = (type: string) => {
    setActiveTypeFilter(type);
  };
  
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-black overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="relative z-10 max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our <span className="text-purple-500">Releases</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Explore our catalog of cutting-edge music from our talented artists.
            </p>
          </div>
        </div>
        <div className="absolute right-0 top-0 w-full h-full opacity-20">
          <div className="absolute right-[-10%] top-[10%] w-[600px] h-[600px] rounded-full bg-purple-700 blur-[120px]"></div>
          <div className="absolute right-[20%] bottom-[-10%] w-[500px] h-[500px] rounded-full bg-blue-700 blur-[120px]"></div>
        </div>
      </section>

      {/* Featured Release */}
      <section className="py-16 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <div className="relative rounded-xl overflow-hidden">
            <div className="absolute inset-0 z-0">
              <img 
                src="https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg" 
                alt="Midnight Dreams by Luna Nova" 
                className="w-full h-full object-cover object-center"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
            </div>
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12 lg:p-16">
              <div className="flex flex-col justify-center">
                <div className="inline-flex items-center mb-4">
                  <span className="bg-purple-600 text-white text-xs font-medium px-3 py-1 rounded-full">Featured Release</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">Midnight Dreams</h2>
                <p className="text-xl text-purple-400 mb-4">By Luna Nova</p>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  An immersive journey through atmospheric electronic soundscapes, "Midnight Dreams" showcases Luna Nova's signature blend of ambient textures and ethereal melodies.
                </p>
                
                <div className="flex flex-wrap gap-4 mb-6">
                  <div className="flex items-center text-gray-400 text-sm">
                    <Calendar className="h-4 w-4 mr-1" />
                    <span>Released: May 15, 2025</span>
                  </div>
                  <div className="flex items-center text-gray-400 text-sm">
                    <Disc className="h-4 w-4 mr-1" />
                    <span>EP - 5 Tracks</span>
                  </div>
                  <div className="flex items-center text-gray-400 text-sm">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>23 minutes</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-4">
                  <Button 
                    href="https://spotify.com" 
                    variant="primary" 
                    icon={<Play className="h-4 w-4" />}
                  >
                    Listen Now
                  </Button>
                  <Button 
                    href="#tracklist" 
                    variant="outline"
                  >
                    View Tracklist
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
            <h2 className="text-2xl font-bold text-white">All Releases</h2>
            
            <button 
              className="flex items-center text-gray-300 text-sm bg-gray-800 px-4 py-2 rounded-lg md:hidden"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-2" />
              {showFilters ? 'Hide Filters' : 'Show Filters'}
            </button>
          </div>
          
          <div className={`md:flex flex-col md:flex-row justify-between gap-4 mb-8 ${showFilters ? 'flex' : 'hidden'}`}>
            <div className="flex flex-wrap gap-3 mb-4 md:mb-0">
              <span className="text-gray-400 text-sm self-center mr-2">Genre:</span>
              {categoryFilters.map((filter) => (
                <button
                  key={filter.id}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${
                    activeCategoryFilter === filter.id
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                  }`}
                  onClick={() => handleCategoryFilter(filter.id)}
                >
                  {filter.label}
                </button>
              ))}
            </div>
            
            <div className="flex flex-wrap gap-3">
              <span className="text-gray-400 text-sm self-center mr-2">Type:</span>
              {typeFilters.map((filter) => (
                <button
                  key={filter.id}
                  className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${
                    activeTypeFilter === filter.id
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
                  }`}
                  onClick={() => handleTypeFilter(filter.id)}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {releases.map((release, index) => (
              <ReleaseCard key={index} release={release} />
            ))}
          </div>
        </div>
      </section>

      {/* Tracklist Section */}
      <section id="tracklist" className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-white mb-8">
            Midnight Dreams - <span className="text-purple-500">Tracklist</span>
          </h2>
          
          <div className="bg-gray-800 rounded-lg overflow-hidden">
            {tracklist.map((track, index) => (
              <div 
                key={index} 
                className={`flex items-center p-4 md:p-6 ${
                  index < tracklist.length - 1 ? 'border-b border-gray-700' : ''
                } hover:bg-gray-700 transition-colors duration-200`}
              >
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-700 text-white mr-4">
                  {track.isPlaying ? (
                    <div className="flex items-center justify-center space-x-1">
                      <div className="w-1 h-3 bg-purple-500 animate-pulse"></div>
                      <div className="w-1 h-4 bg-purple-500 animate-pulse delay-75"></div>
                      <div className="w-1 h-2 bg-purple-500 animate-pulse delay-150"></div>
                    </div>
                  ) : (
                    <span className="text-sm">{index + 1}</span>
                  )}
                </div>
                
                <div className="flex-grow">
                  <h3 className={`font-medium ${track.isPlaying ? 'text-purple-400' : 'text-white'}`}>
                    {track.title}
                  </h3>
                  <p className="text-gray-400 text-sm">Luna Nova</p>
                </div>
                
                <div className="flex items-center">
                  <span className="text-gray-400 text-sm mr-4">{track.duration}</span>
                  <button 
                    className={`w-8 h-8 flex items-center justify-center rounded-full ${
                      track.isPlaying 
                        ? 'bg-purple-600 text-white' 
                        : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                    }`}
                  >
                    <Play className="h-4 w-4" fill="currentColor" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Streaming Links */}
      <section className="py-16 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-white mb-8">
            Listen On Your Favorite Platform
          </h2>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {streamingPlatforms.map((platform, index) => (
              <a 
                key={index}
                href={platform.url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gray-800 hover:bg-gray-700 transition-colors duration-300 p-6 rounded-lg flex flex-col items-center justify-center"
              >
                <div className="text-white mb-2">
                  {platform.icon}
                </div>
                <span className="text-gray-300 text-sm">{platform.name}</span>
              </a>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

type Release = {
  title: string;
  artist: string;
  cover: string;
  type: string;
  releaseDate: string;
  genres: string[];
};

const ReleaseCard = ({ release }: { release: Release }) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden group hover:shadow-xl transition-all duration-300 hover:shadow-purple-900/20">
      <div className="relative overflow-hidden">
        <img 
          src={release.cover} 
          alt={`${release.title} by ${release.artist}`} 
          className="w-full aspect-square object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="bg-purple-600 rounded-full p-3 transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play className="h-6 w-6 text-white" fill="currentColor" />
          </div>
        </div>
        <div className="absolute top-2 right-2 bg-purple-600 text-white text-xs font-medium px-2 py-1 rounded">
          {release.type}
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-white font-semibold text-lg truncate">{release.title}</h3>
        <p className="text-purple-400 text-sm mb-2">{release.artist}</p>
        <div className="flex flex-wrap gap-2 mb-2">
          {release.genres.map((genre, index) => (
            <span key={index} className="text-gray-400 text-xs">
              {genre}
            </span>
          ))}
        </div>
        <div className="flex items-center text-gray-500 text-xs">
          <Calendar className="h-3 w-3 mr-1" />
          {release.releaseDate}
        </div>
      </div>
    </div>
  );
};

const categoryFilters = [
  { id: 'all', label: 'All Genres' },
  { id: 'electronic', label: 'Electronic' },
  { id: 'ambient', label: 'Ambient' },
  { id: 'indie', label: 'Indie' },
  { id: 'experimental', label: 'Experimental' }
];

const typeFilters = [
  { id: 'all', label: 'All Types' },
  { id: 'album', label: 'Albums' },
  { id: 'ep', label: 'EPs' },
  { id: 'single', label: 'Singles' }
];

const releases: Release[] = [
  {
    title: "Midnight Dreams",
    artist: "Luna Nova",
    cover: "https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg",
    type: "EP",
    releaseDate: "May 15, 2025",
    genres: ["Electronic", "Ambient"]
  },
  {
    title: "Echoes of Tomorrow",
    artist: "Skyler James",
    cover: "https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg",
    type: "Single",
    releaseDate: "April 28, 2025",
    genres: ["Indie", "Alternative"]
  },
  {
    title: "Neon Future",
    artist: "The Electric Collective",
    cover: "https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg",
    type: "Album",
    releaseDate: "April 10, 2025",
    genres: ["Electronic", "Synth"]
  },
  {
    title: "Resonance",
    artist: "Aria Waves",
    cover: "https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg",
    type: "Single",
    releaseDate: "March 25, 2025",
    genres: ["Ambient", "Downtempo"]
  },
  {
    title: "Quantum Fields",
    artist: "Quantum Fields",
    cover: "https://images.pexels.com/photos/1694900/pexels-photo-1694900.jpeg",
    type: "EP",
    releaseDate: "March 12, 2025",
    genres: ["Experimental", "IDM"]
  },
  {
    title: "Urban Jazz",
    artist: "Jazz Nebula",
    cover: "https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg",
    type: "Album",
    releaseDate: "February 28, 2025",
    genres: ["Jazz", "Fusion"]
  },
  {
    title: "Retro Wave",
    artist: "Neon Pulse",
    cover: "https://images.pexels.com/photos/3800541/pexels-photo-3800541.jpeg",
    type: "EP",
    releaseDate: "February 14, 2025",
    genres: ["Synthwave", "Electronic"]
  },
  {
    title: "Ethereal Spaces",
    artist: "Luna Nova",
    cover: "https://images.pexels.com/photos/3721941/pexels-photo-3721941.jpeg",
    type: "Single",
    releaseDate: "January 30, 2025",
    genres: ["Ambient", "Electronic"]
  }
];

const tracklist = [
  {
    title: "Lunar Eclipse",
    duration: "4:28",
    isPlaying: true
  },
  {
    title: "Midnight Reverie",
    duration: "5:12",
    isPlaying: false
  },
  {
    title: "Stardust",
    duration: "3:56",
    isPlaying: false
  },
  {
    title: "Dream Sequence",
    duration: "6:03",
    isPlaying: false
  },
  {
    title: "Celestial",
    duration: "3:21",
    isPlaying: false
  }
];

const streamingPlatforms = [
  {
    name: "Spotify",
    url: "https://spotify.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
      </svg>
    )
  },
  {
    name: "Apple Music",
    url: "https://music.apple.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.997 6.124c0-.738-.065-1.47-.24-2.19-.317-1.31-1.062-2.31-2.18-3.043C21.003.517 20.373.285 19.7.164c-.517-.093-1.038-.135-1.564-.15-.04-.003-.083-.01-.124-.013H5.988c-.152.01-.303.017-.455.026C4.786.07 4.043.15 3.34.428 2.004.958 1.04 1.88.48 3.208c-.192.45-.29.908-.345 1.378-.063.51-.072 1.026-.072 1.54V17.88c.01.147.015.295.022.442.016.42.032.84.073 1.26.098.845.286 1.662.74 2.395.5.814 1.17 1.425 2.01 1.855.398.2.814.34 1.253.43.613.125 1.236.145 1.86.147.37.01.74.01 1.11.01h9.293c.41-.01.82-.01 1.23-.02.394-.01.79-.06 1.18-.14.45-.094.883-.231 1.293-.435.833-.4 1.48-.97 1.996-1.76.442-.684.706-1.46.82-2.262.05-.33.063-.662.09-.995.01-.172.01-.345.01-.517V7.974c-.01-.147-.014-.295-.022-.442-.01-.21-.022-.422-.036-.635-.094-1.05-.368-2.015-1.102-2.82-.574-.63-1.28-1.05-2.083-1.297-.32-.096-.65-.154-.983-.19-.31-.033-.63-.05-.95-.055-.156-.004-.31-.01-.465-.012z"/>
        <path d="M12.14 4.466c.593 0 1.882-.139 3.142-.93 1.326-.833 2.48-2.304 2.675-3.65.072-.514.11-.937.11-1.31 0-.373-.022-.695-.053-.94-.015-.11-.034-.24-.057-.335C17.303.027 15.677 0 15.14 0c-.67 0-1.508.152-2.33.507-1.26.537-2.5 1.724-2.947 3.472-.127.5-.186.94-.186 1.344 0 .403.058.797.155 1.15.165.593.611 1.948 2.31 1.992.066.002.133.002.2.002zm8.433 12.92c-.204.757-.44 1.334-.788 1.73-.356.4-.735.6-1.13.6-.57 0-1.022-.195-1.458-.592-.473-.429-1.115-1.149-2.432-1.149-1.332 0-1.97.717-2.454 1.164-.42.39-.866.574-1.36.574-.62 0-1.16-.355-1.57-.762a7.126 7.126 0 01-.475-.532c-.336-.4-.75-.896-1.435-1.297-.342-.2-.5-.147-.6-.08-.103.064-.175.192-.175.38 0 .173.077.35.213.533.136.182.36.41.66.636.376.26.97.676 1.282 1.25.332.615 1.158 1.926 2.69 1.926 1.524 0 2.658-.869 3.13-1.292.3-.265.532-.528.736-.684.227-.175.412-.275.58-.275.168.001.336.101.536.275.135.099.418.35.954.672.753.455 1.422.663 2.098.663.827 0 1.71-.353 2.02-1.859.13-.631.035-1.394-.428-2.29z" fill="#FFF"/>
      </svg>
    )
  },
  {
    name: "YouTube Music",
    url: "https://music.youtube.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 0C5.376 0 0 5.376 0 12s5.376 12 12 12 12-5.376 12-12S18.624 0 12 0zm0 19.104c-3.924 0-7.104-3.18-7.104-7.104S8.076 4.896 12 4.896s7.104 3.18 7.104 7.104-3.18 7.104-7.104 7.104zm0-13.332c-3.432 0-6.228 2.796-6.228 6.228S8.568 18.228 12 18.228s6.228-2.796 6.228-6.228S15.432 5.772 12 5.772zM9.684 15.54V8.46L16.2 12l-6.516 3.54z"/>
      </svg>
    )
  },
  {
    name: "Amazon Music",
    url: "https://music.amazon.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M.045 18.02c.072-.116.187-.124.348-.022 3.636 2.11 7.594 3.166 11.87 3.166 2.852 0 5.668-.533 8.447-1.595l.315-.14c.138-.06.234-.1.293-.13.226-.088.39-.046.525.13.12.174.09.336-.12.48-.256.19-.6.41-1.006.654-1.244.743-2.64 1.316-4.185 1.726a17.617 17.617 0 01-10.951-.577 17.88 17.88 0 01-5.43-3.35c-.1-.074-.151-.15-.151-.22 0-.047.021-.09.051-.13zm6.565-6.218c0-1.005.247-1.863.743-2.577.495-.71 1.17-1.25 2.04-1.615.796-.335 1.756-.575 2.912-.72.39-.046 1.033-.103 1.92-.174v-.37c0-.93-.105-1.558-.3-1.875-.302-.43-.812-.65-1.53-.65h-.21c-.53.027-.97.175-1.305.42-.335.25-.575.532-.675.848-.06.18-.206.22-.435.12l-1.65-.63c-.226-.09-.27-.18-.165-.33.63-1.005 1.4-1.707 2.315-2.107.916-.4 1.878-.6 2.9-.6.97 0 1.79.145 2.465.43.675.285 1.186.686 1.526 1.215.34.53.536 1.1.59 1.71.05.608.075 1.67.075 3.2v5.355c0 .245.105.36.3.36h.15c.15 0 .27.046.36.135l.3.36c.09.12.045.226-.15.307-1.02.565-1.68.855-1.95.855-.225 0-.42-.08-.57-.225a2.434 2.434 0 01-.37-.57c-.045-.15-.145-.21-.28-.196-.15 0-.3.06-.45.18-1.080.765-2.266 1.147-3.539 1.147-1.036 0-1.88-.29-2.535-.878-.66-.585-.975-1.366-.975-2.34zm3.285.084c0 .608.215 1.083.63 1.425.42.34.915.51 1.5.51.63 0 1.27-.236 1.935-.704.225-.15.385-.33.48-.524.09-.196.136-.54.136-1.005v-1.876l-1.035.07c-.676.05-1.215.18-1.62.39-.405.21-.704.479-.915.81-.225.315-.331.7-.331 1.155zm10.091 2.56c-1.213 1.126-2.87 1.688-4.966 1.688-.18 0-.36-.006-.54-.026a9.044 9.044 0 01-3.51-1.182c-.15-.09-.165-.18-.09-.285l.63-.975c.06-.105.15-.12.27-.06 1.126.58 2.25.87 3.39.87.405 0 .796-.046 1.17-.136a2.131 2.131 0 001.455-1.094c.165-.345.225-.78.225-1.29V8.12c-2.592.06-4.456.547-5.61 1.468a4.77 4.77 0 00-1.724 3.80c0 1.275.345 2.27 1.036 2.997.69.735 1.66 1.096 2.91 1.096 1.365 0 2.66-.6 3.9-1.802.165-.15.27-.134.331.02l.181.359c.045.105.136.166.256.166h.796c.206 0 .322-.076.346-.226l.555-3.78c.07-.496.082-1 .045-1.51-.036-.496-.07-.945-.121-1.35-.045-.256-.071-.511-.091-.781a17.46 17.46 0 00-.075-.797c-.016-.105-.026-.225-.046-.33-.06-.376-.165-.706-.315-.991-.3-.571-.766-1.023-1.396-1.336-.63-.316-1.38-.474-2.235-.474-.915 0-1.731.21-2.445.627-.18.102-.331.215-.481.329l-.225.21c-.091.08-.151.072-.196-.046a2.913 2.913 0 01-.076-.33L12.15 4.064c-.046-.18.015-.27.180-.27h1.694c.185 0 .346.09.391.272l.165.706c.015.15.091.195.225.119 1.216-.706 2.49-1.056 3.825-1.056 1.425 0 2.535.48 3.33 1.434.795.958 1.155 2.359 1.155 4.202v5.3c0 .165.06.225.181.225h.93c.15 0 .27.046.36.136l.3.36c.09.12.046.225-.15.307-1.126.6-1.831.899-2.13.899-.226 0-.436-.066-.631-.196a1.987 1.987 0 01-.436-.452c-.075-.12-.24-.134-.48-.014z"/>
      </svg>
    )
  },
  {
    name: "SoundCloud",
    url: "https://soundcloud.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M1.175 12.225c-.051 0-.094.046-.101.1l-.233 2.154.233 2.105c.007.058.05.098.101.098.05 0 .09-.04.099-.098l.255-2.105-.27-2.154c0-.057-.045-.1-.084-.1m-.899.828c-.06 0-.091.037-.104.094L0 14.479l.165 1.308c0 .055.045.094.09.094s.089-.045.104-.104l.21-1.319-.21-1.334c0-.061-.044-.09-.09-.09m1.83-1.229c-.061 0-.12.045-.12.104l-.21 2.563.225 2.458c0 .06.045.12.119.12.061 0 .105-.061.121-.12l.254-2.474-.254-2.548c-.016-.06-.061-.12-.121-.12m.945-.089c-.075 0-.135.06-.15.135l-.193 2.64.21 2.544c.016.077.075.138.149.138.075 0 .135-.061.15-.15l.24-2.532-.24-2.642c0-.075-.06-.135-.135-.135l-.031-.017zm1.155.36c-.005-.09-.075-.149-.159-.149-.09 0-.158.06-.164.149L3.61 14.722l.179 2.391c.005.09.075.15.164.15.075 0 .157-.06.164-.15l.24-2.406-.225-2.66h-.029zm.809-.299c-.104 0-.18.09-.18.18l-.165 2.94.164 2.299c0 .09.075.165.18.165s.18-.074.189-.165l.195-2.299-.195-2.94c0-.09-.075-.18-.18-.18m.959-.045c-.105 0-.195.09-.203.194l-.15 2.99.165 2.187c0 .105.09.195.195.195.104 0 .194-.09.193-.195l.18-2.187-.18-2.99c.001-.104-.088-.195-.193-.195l-.007.001zm1.044-.06c-.12 0-.209.09-.209.209l-.139 3.043.139 2.176c.007.119.089.209.209.209.105 0 .195-.089.202-.209l.156-2.176-.156-3.043c-.007-.119-.097-.209-.202-.209zm1.155.045c-.135 0-.225.09-.225.225l-.12 2.982.119 2.175c.008.135.09.226.225.226.135 0 .226-.09.225-.226l.135-2.175-.135-2.982c0-.135-.09-.225-.225-.225zm1.201-.24c-.137 0-.248.111-.248.248l-.102 3.199.103 2.16c0 .139.111.25.248.25.135 0 .248-.111.247-.25l.12-2.159-.12-3.198c0-.135-.111-.25-.248-.25l.002.001zm1.197-.091c-.15 0-.27.121-.27.271l-.092 3.268.091 2.144c0 .149.121.27.271.27s.271-.121.27-.27l.103-2.144-.103-3.268c0-.15-.121-.271-.271-.271zm1.306.051c-.164 0-.299.135-.299.299l-.073 3.188.073 2.134c0 .164.135.299.299.299.164 0 .299-.135.299-.299l.09-2.134-.09-3.188c0-.164-.145-.299-.299-.299zm1.354-.061c-.18 0-.314.149-.314.314l-.06 3.286.06 2.12c0 .18.135.314.314.314.18 0 .315-.135.315-.314l.075-2.119-.075-3.287c0-.172-.135-.314-.315-.314zm6.406.781c-.331 0-.607.253-.607.599v5.658c0 .346.276.599.607.599.33 0 .606-.253.606-.599v-5.658c0-.346-.276-.599-.606-.599z"/>
      </svg>
    )
  },
  {
    name: "Bandcamp",
    url: "https://bandcamp.com",
    icon: (
      <svg className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
        <path d="M0 18.75l7.437-13.5H24l-7.438 13.5H0z"/>
      </svg>
    )
  }
];

export default ReleasesPage;