import React, { useEffect, useRef } from 'react';
import { Play, User, Disc, Calendar, ChevronRight, Music, Zap, Star } from 'lucide-react';
import Button from '../components/ui/Button';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Create floating particles
    const createParticle = () => {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.width = Math.random() * 4 + 2 + 'px';
      particle.style.height = particle.style.width;
      particle.style.animationDelay = Math.random() * 20 + 's';
      
      const particlesContainer = document.querySelector('.particles');
      if (particlesContainer) {
        particlesContainer.appendChild(particle);
        
        setTimeout(() => {
          particle.remove();
        }, 30000);
      }
    };

    const interval = setInterval(createParticle, 300);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden dark-bg">
        {/* Animated background particles */}
        <div className="particles absolute inset-0 z-0"></div>
        
        {/* Background image with overlay */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-gray-950 via-gray-950/90 to-gray-950/80"></div>
          <img 
            src="https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg" 
            alt="Music studio" 
            className="absolute inset-0 w-full h-full object-cover object-center opacity-30"
          />
          {/* Animated gradient overlay */}
          <div className="absolute inset-0 animated-gradient opacity-20"></div>
        </div>

        {/* Floating music icons */}
        <div className="absolute inset-0 z-5">
          <Music className="absolute top-20 left-10 w-6 h-6 text-purple-500/30 animate-float" style={{animationDelay: '0s'}} />
          <Disc className="absolute top-40 right-20 w-8 h-8 text-blue-500/30 animate-float" style={{animationDelay: '2s'}} />
          <Zap className="absolute bottom-40 left-20 w-5 h-5 text-purple-400/30 animate-float" style={{animationDelay: '4s'}} />
          <Star className="absolute top-60 left-1/3 w-4 h-4 text-blue-400/30 animate-float" style={{animationDelay: '1s'}} />
          <Music className="absolute bottom-60 right-1/3 w-7 h-7 text-purple-300/30 animate-float" style={{animationDelay: '3s'}} />
        </div>

        <div className="relative z-10 container mx-auto px-4 py-24 md:py-32 flex flex-col items-center text-center">
          <div className="slide-in-up">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4 tracking-tight">
              <span className="block text-white fade-in-delay-1">Discover The Future</span>
              <span className="bg-gradient-to-r from-purple-400 via-purple-500 to-blue-500 bg-clip-text text-transparent neon-glow fade-in-delay-2">
              Of Sound
              </span>
            </h1>
          </div>
          
          <div className="slide-in-up" style={{animationDelay: '0.3s'}}>
            <p className="text-gray-300 text-lg md:text-xl max-w-3xl mx-auto mb-10 leading-relaxed fade-in-delay-3">
              JSJ Music is a forward-thinking label dedicated to discovering exceptional talent and pushing musical boundaries.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-4 fade-in-delay-4">
            <Button to="/releases" size="large" icon={<Play size={18} />} className="hover-glow">
              Explore Our Music
            </Button>
            <Button to="/about" variant="outline" size="large" className="hover-lift">
              About The Label
            </Button>
          </div>
          
          {/* Music visualizer bars */}
          <div className="mt-12 music-bars fade-in-delay-4">
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
          </div>
        </div>

        <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce-slow">
          <a href="#latest-releases" className="text-white/70 hover:text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
            </svg>
          </a>
        </div>
      </section>

      {/* Latest Releases Section */}
      <section id="latest-releases" className="py-20 dark-bg-secondary relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(147, 51, 234, 0.1) 0%, transparent 50%),
                             radial-gradient(circle at 75% 75%, rgba(59, 130, 246, 0.1) 0%, transparent 50%)`
          }}></div>
        </div>
        
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 md:mb-0 slide-in-left">
              Latest <span className="text-purple-400 neon-glow">Releases</span>
            </h2>
            <Button to="/releases" variant="outline" icon={<ChevronRight size={16} />} className="hover-lift slide-in-right">
              View All Releases
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {releases.map((release, index) => (
              <div key={index} className="fade-in-delay-1" style={{animationDelay: `${index * 0.1}s`}}>
                <ReleaseCard release={release} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Artists */}
      <section className="py-20 dark-bg relative">
        {/* Rotating background elements */}
        <div className="absolute top-20 right-20 w-32 h-32 border border-purple-500/20 rounded-full rotate-slow"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 border border-blue-500/20 rounded-full rotate-slow" style={{animationDirection: 'reverse'}}></div>
        
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 md:mb-0 slide-in-left">
              Featured <span className="text-purple-400 neon-glow">Artists</span>
            </h2>
            <Button to="/artists" variant="outline" icon={<ChevronRight size={16} />} className="hover-lift slide-in-right">
              View All Artists
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredArtists.map((artist, index) => (
              <div key={index} className="fade-in-delay-2" style={{animationDelay: `${index * 0.2}s`}}>
                <ArtistCard artist={artist} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 dark-bg-secondary relative overflow-hidden">
        {/* Animated background shapes */}
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl animate-pulse-slow" style={{animationDelay: '1s'}}></div>
        </div>
        
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative slide-in-left">
              <div className="aspect-square rounded-lg overflow-hidden hover-lift">
                <img 
                  src="https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg" 
                  alt="JSJ Music Studios" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-gradient-to-br from-purple-600 to-blue-600 w-40 h-40 rounded-lg flex items-center justify-center p-4 shadow-glow animate-glow">
                <p className="text-white text-center font-semibold">
                  <span className="block text-3xl font-bold">10+</span>
                  <span className="text-sm">Years in Music</span>
                </p>
              </div>
            </div>
            
            <div className="slide-in-right">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                The Story Behind <span className="text-purple-400 neon-glow">JSJ Music</span>
              </h2>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Founded in 2015, JSJ Music was born from a passion for discovering groundbreaking musical talents and providing them a platform to share their art with the world. Our label is more than just a business—it's a community of artists, producers, and music lovers united by a shared vision.
              </p>
              <p className="text-gray-300 mb-8 leading-relaxed">
                We pride ourselves on nurturing genuine creative expression while supporting our artists with the resources and expertise they need to reach their full potential. From electronic to indie, from jazz to hip-hop, we embrace diversity in sound and culture.
              </p>
              <Button to="/about" variant="primary" className="hover-glow">Learn More About Us</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 animated-gradient relative overflow-hidden">
        {/* Floating elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-2 h-2 bg-white rounded-full animate-ping-slow"></div>
          <div className="absolute top-20 right-20 w-1 h-1 bg-purple-400 rounded-full animate-ping-slow" style={{animationDelay: '1s'}}></div>
          <div className="absolute bottom-20 left-1/3 w-1.5 h-1.5 bg-blue-400 rounded-full animate-ping-slow" style={{animationDelay: '2s'}}></div>
        </div>
        
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6 slide-in-up neon-glow">
            Ready to Join the JSJ Music Family?
          </h2>
          <p className="text-gray-200 max-w-2xl mx-auto mb-8 leading-relaxed slide-in-up" style={{animationDelay: '0.2s'}}>
            Whether you're an artist looking for representation or a music lover wanting to stay updated on our latest releases, we'd love to connect with you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center slide-in-up" style={{animationDelay: '0.4s'}}>
            <Button to="/contact" size="large" className="hover-glow">
              Submit Your Demo
            </Button>
            <Button to="/contact" variant="outline" size="large" className="hover-lift">
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

type Release = {
  title: string;
  artist: string;
  cover: string;
  type: string;
  releaseDate: string;
};

const ReleaseCard = ({ release }: { release: Release }) => {
  return (
    <div className="bg-gray-900/50 backdrop-blur-sm rounded-lg overflow-hidden group hover-lift border border-gray-800/50 hover:border-purple-500/30 transition-all duration-500">
      <div className="relative overflow-hidden">
        <img 
          src={release.cover} 
          alt={`${release.title} by ${release.artist}`} 
          className="w-full aspect-square object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
          <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-full p-3 transform scale-75 group-hover:scale-100 transition-transform duration-500 shadow-glow">
            <Play className="h-6 w-6 text-white" fill="currentColor" />
          </div>
        </div>
        <div className="absolute top-2 right-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs font-medium px-2 py-1 rounded shadow-glow">
          {release.type}
        </div>
      </div>
      <div className="p-4">
        <h3 className="text-white font-semibold text-lg truncate">{release.title}</h3>
        <p className="text-purple-400 text-sm">{release.artist}</p>
        <div className="flex items-center mt-2 text-gray-500 text-xs">
          <Calendar className="h-3 w-3 mr-1" />
          {release.releaseDate}
        </div>
      </div>
    </div>
  );
};

type Artist = {
  name: string;
  image: string;
  genre: string;
};

const ArtistCard = ({ artist }: { artist: Artist }) => {
  return (
    <Link to="/artists" className="group block">
      <div className="relative overflow-hidden rounded-lg hover-lift border border-gray-800/50 hover:border-purple-500/30 transition-all duration-500">
        <img 
          src={artist.image} 
          alt={artist.name} 
          className="w-full aspect-[4/5] object-cover object-center transition-transform duration-1000 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/50 to-transparent">
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="flex items-center mb-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 flex items-center justify-center mr-3 shadow-glow">
                <User className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-white font-bold text-xl">{artist.name}</h3>
                <p className="text-purple-300 text-sm">{artist.genre}</p>
              </div>
            </div>
            <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-700 shadow-glow"></div>
          </div>
        </div>
      </div>
    </Link>
  );
};

// Sample data
const releases: Release[] = [
  {
    title: "Midnight Dreams - EP",
    artist: "Luna Nova",
    cover: "https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg",
    type: "EP",
    releaseDate: "May 15, 2025"
  },
  {
    title: "Echoes of Tomorrow",
    artist: "Skyler James",
    cover: "https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg",
    type: "Single",
    releaseDate: "April 28, 2025"
  },
  {
    title: "Neon Future",
    artist: "The Electric Collective",
    cover: "https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg",
    type: "Album",
    releaseDate: "April 10, 2025"
  },
  {
    title: "Resonance",
    artist: "Aria Waves",
    cover: "https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg",
    type: "Single",
    releaseDate: "March 25, 2025"
  }
];

const featuredArtists: Artist[] = [
  {
    name: "Luna Nova",
    image: "https://images.pexels.com/photos/1699159/pexels-photo-1699159.jpeg",
    genre: "Electronic / Ambient"
  },
  {
    name: "Skyler James",
    image: "https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg",
    genre: "Alternative / Indie"
  },
  {
    name: "The Electric Collective",
    image: "https://images.pexels.com/photos/167636/pexels-photo-167636.jpeg",
    genre: "Synth / Electronic"
  }
];

export default HomePage;