import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';

export default function AdminDashboard() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api('/admin/overview')
      .then((data) => setUsers(data.users))
      .catch((e) => setError(e?.body?.error || 'Fehler'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-6">Lade...</div>;
  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Admin Dashboard</h1>
      {error && <div className="text-red-400">{error}</div>}
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="text-zinc-400">
              <th className="p-2">ID</th>
              <th className="p-2">Email</th>
              <th className="p-2">Rolle</th>
              <th className="p-2">Erstellt</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} className="border-t border-zinc-800">
                <td className="p-2">{u.id}</td>
                <td className="p-2">{u.email}</td>
                <td className="p-2">{u.role}</td>
                <td className="p-2">{new Date(u.created_at).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
