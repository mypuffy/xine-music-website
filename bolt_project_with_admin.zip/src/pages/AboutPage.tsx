import React from 'react';
import { Award, Headphones, Globe, Users, Music, Disc } from 'lucide-react';
import Button from '../components/ui/Button';

const AboutPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-black overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="relative z-10 max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              About <span className="text-purple-500">JSJ Music</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              A forward-thinking music label dedicated to pushing boundaries and discovering exceptional talent.
            </p>
          </div>
        </div>
        <div className="absolute right-0 top-0 w-full h-full opacity-20">
          <div className="absolute right-[-10%] top-[10%] w-[600px] h-[600px] rounded-full bg-purple-700 blur-[120px]"></div>
          <div className="absolute right-[20%] bottom-[-10%] w-[500px] h-[500px] rounded-full bg-blue-700 blur-[120px]"></div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-6">
                Our <span className="text-purple-500">Story</span>
              </h2>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Founded in 2015 by a group of passionate music producers and industry professionals, JSJ Music was born from a collective desire to challenge the status quo of the music industry. We noticed a gap in the market for artists who were creating innovative, boundary-pushing music but lacked the resources and support to reach a wider audience.
              </p>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Starting with just three artists in a small studio in Los Angeles, we've grown to represent over 20 diverse artists across multiple genres. Our journey hasn't been without challenges, but our commitment to musical integrity and artist development has remained steadfast.
              </p>
              <p className="text-gray-300 leading-relaxed">
                Today, JSJ Music stands as a beacon for musical innovation, with a catalog of acclaimed releases and a community of dedicated listeners worldwide. But despite our growth, we remain true to our founding principle: music first, business second.
              </p>
            </div>

            <div className="relative">
              <div className="aspect-video rounded-lg overflow-hidden shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/164938/pexels-photo-164938.jpeg" 
                  alt="JSJ Music Studio" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-8 -left-8 w-64 bg-gray-900 p-4 rounded shadow-xl border border-gray-800">
                <div className="flex items-center">
                  <Music className="h-5 w-5 text-purple-500 mr-2" />
                  <p className="text-gray-200 font-medium">Founded in 2015</p>
                </div>
                <div className="w-full h-px bg-gray-800 my-3"></div>
                <div className="flex items-center">
                  <Disc className="h-5 w-5 text-purple-500 mr-2" />
                  <p className="text-gray-200 font-medium">100+ releases</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-12">
            Our <span className="text-purple-500">Mission</span>
          </h2>
          
          <div className="max-w-3xl mx-auto mb-16">
            <p className="text-xl text-gray-300 leading-relaxed">
              At JSJ Music, our mission is to discover, develop, and showcase extraordinary musical talent that pushes creative boundaries and resonates with audiences worldwide.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {missionPoints.map((point, index) => (
              <div 
                key={index} 
                className="bg-gray-800 p-6 rounded-lg transition-transform hover:-translate-y-2 duration-300"
              >
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-600 text-white mb-4">
                  {point.icon}
                </div>
                <h3 className="text-xl font-semibold text-white mb-3">{point.title}</h3>
                <p className="text-gray-400 leading-relaxed">{point.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">
            Our <span className="text-purple-500">Values</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div 
                key={index} 
                className="relative overflow-hidden rounded-lg group"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-blue-900/80 opacity-90 group-hover:opacity-100 transition-opacity duration-300"></div>
                <img 
                  src={value.image} 
                  alt={value.title}
                  className="w-full aspect-video object-cover"
                />
                <div className="absolute inset-0 flex flex-col justify-center p-8">
                  <h3 className="text-2xl font-bold text-white mb-3">{value.title}</h3>
                  <p className="text-gray-200">{value.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12 text-center">
            Meet Our <span className="text-purple-500">Team</span>
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
            {teamMembers.map((member, index) => (
              <div 
                key={index} 
                className="group"
              >
                <div className="relative mb-4 overflow-hidden rounded-lg">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full aspect-[3/4] object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-80"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-xl font-bold text-white">{member.name}</h3>
                    <p className="text-purple-400">{member.role}</p>
                  </div>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">{member.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-purple-900 to-blue-900">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Want to work with us?
          </h2>
          <p className="text-gray-200 max-w-2xl mx-auto mb-8 leading-relaxed">
            We're always looking for talented individuals to join our team or artists to add to our roster. Get in touch to explore opportunities.
          </p>
          <Button to="/contact" size="large">
            Contact Us
          </Button>
        </div>
      </section>
    </div>
  );
};

const missionPoints = [
  {
    icon: <Award className="h-6 w-6" />,
    title: "Musical Excellence",
    description: "We strive for excellence in every release, prioritizing artistic integrity and quality above all else."
  },
  {
    icon: <Users className="h-6 w-6" />,
    title: "Artist Development",
    description: "We invest in our artists' growth, providing resources, mentorship, and support to help them realize their creative vision."
  },
  {
    icon: <Globe className="h-6 w-6" />,
    title: "Global Reach",
    description: "We connect innovative music with audiences worldwide, breaking down geographical barriers through digital distribution and promotion."
  }
];

const values = [
  {
    title: "Artistic Integrity",
    description: "We believe in giving artists the creative freedom to express their authentic voice, without compromising their vision for commercial gain.",
    image: "https://images.pexels.com/photos/2531728/pexels-photo-2531728.jpeg"
  },
  {
    title: "Innovation & Experimentation",
    description: "We embrace risk-taking and experimentation, encouraging our artists to push boundaries and explore new sounds and approaches.",
    image: "https://images.pexels.com/photos/1751731/pexels-photo-1751731.jpeg"
  },
  {
    title: "Community & Collaboration",
    description: "We foster a collaborative community where artists can connect, share ideas, and grow together through mutual support and creative exchange.",
    image: "https://images.pexels.com/photos/2526105/pexels-photo-2526105.jpeg"
  },
  {
    title: "Diversity & Inclusion",
    description: "We celebrate diverse voices and perspectives, actively seeking out and amplifying artists from all backgrounds and musical traditions.",
    image: "https://images.pexels.com/photos/761543/pexels-photo-761543.jpeg"
  }
];

const teamMembers = [
  {
    name: "Jordan Smith",
    role: "Founder & CEO",
    bio: "With over 15 years in the music industry as a producer and executive, Jordan founded JSJ Music to create a home for boundary-pushing artists.",
    image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg"
  },
  {
    name: "Sarah Johnson",
    role: "A&R Director",
    bio: "Sarah has an exceptional ear for identifying unique talent and helping artists refine their sound while staying true to their creative vision.",
    image: "https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg"
  },
  {
    name: "James Wilson",
    role: "Head Producer",
    bio: "A Grammy-nominated producer, James brings technical expertise and creative insight to help our artists realize their musical vision in the studio.",
    image: "https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg"
  }
];

export default AboutPage;