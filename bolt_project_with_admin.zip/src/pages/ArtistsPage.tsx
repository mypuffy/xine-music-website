import React, { useState } from 'react';
import { Music, Play, ExternalLink, Calendar, Disc } from 'lucide-react';
import Button from '../components/ui/Button';

const ArtistsPage = () => {
  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="relative py-24 bg-black overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="relative z-10 max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Our <span className="text-purple-500">Artists</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Discover the exceptional talent behind JSJ Music, pushing the boundaries of sound and creativity.
            </p>
          </div>
        </div>
        <div className="absolute right-0 top-0 w-full h-full opacity-20">
          <div className="absolute right-[-10%] top-[10%] w-[600px] h-[600px] rounded-full bg-purple-700 blur-[120px]"></div>
          <div className="absolute right-[20%] bottom-[-10%] w-[500px] h-[500px] rounded-full bg-blue-700 blur-[120px]"></div>
        </div>
      </section>

      {/* Artist Filters */}
      <section className="py-8 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <ArtistFilters />
        </div>
      </section>

      {/* Featured Artist */}
      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="relative rounded-xl overflow-hidden">
            <div className="absolute inset-0">
              <img 
                src="https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg" 
                alt="Luna Nova" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
            </div>
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12 lg:p-16">
              <div className="flex flex-col justify-center">
                <div className="inline-flex items-center mb-4">
                  <span className="bg-purple-600 text-white text-xs font-medium px-3 py-1 rounded-full">Featured Artist</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Luna Nova</h2>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  Luna Nova creates atmospheric electronic music that blends ambient textures with pulsing rhythms. Her unique sound has earned critical acclaim and a devoted global following. Her latest EP, "Midnight Dreams," showcases her evolution as an artist and her innovative approach to production.
                </p>
                <div className="flex flex-wrap gap-4 mb-6">
                  <span className="bg-gray-800 text-gray-300 text-sm px-3 py-1 rounded-full">Electronic</span>
                  <span className="bg-gray-800 text-gray-300 text-sm px-3 py-1 rounded-full">Ambient</span>
                  <span className="bg-gray-800 text-gray-300 text-sm px-3 py-1 rounded-full">Downtempo</span>
                </div>
                <div className="flex flex-wrap gap-4">
                  <Button 
                    href="https://spotify.com" 
                    variant="primary" 
                    icon={<Play className="h-4 w-4" />}
                  >
                    Listen
                  </Button>
                  <Button 
                    href="https://instagram.com" 
                    variant="outline" 
                    icon={<ExternalLink className="h-4 w-4" />}
                  >
                    Social Media
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Artist Grid */}
      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {artists.map((artist, index) => (
              <ArtistCard key={index} artist={artist} />
            ))}
          </div>
        </div>
      </section>

      {/* Join Call to Action */}
      <section className="py-20 bg-gradient-to-r from-purple-900 to-blue-900">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Want to Join Our Roster?
          </h2>
          <p className="text-gray-200 max-w-2xl mx-auto mb-8 leading-relaxed">
            JSJ Music is always looking for innovative artists who push boundaries and create exceptional music. If that sounds like you, we'd love to hear your work.
          </p>
          <Button to="/contact" size="large" icon={<Music className="h-5 w-5" />}>
            Submit Your Demo
          </Button>
        </div>
      </section>
    </div>
  );
};

const ArtistFilters = () => {
  const [activeFilter, setActiveFilter] = useState('all');
  
  const filters = [
    { id: 'all', label: 'All Artists' },
    { id: 'electronic', label: 'Electronic' },
    { id: 'indie', label: 'Indie' },
    { id: 'ambient', label: 'Ambient' },
    { id: 'experimental', label: 'Experimental' },
    { id: 'jazz', label: 'Jazz' }
  ];
  
  return (
    <div className="flex flex-wrap gap-3">
      {filters.map((filter) => (
        <button
          key={filter.id}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
            activeFilter === filter.id
              ? 'bg-purple-600 text-white'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'
          }`}
          onClick={() => setActiveFilter(filter.id)}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

type Artist = {
  name: string;
  image: string;
  genres: string[];
  featured: boolean;
  bio: string;
  releases: number;
};

const ArtistCard = ({ artist }: { artist: Artist }) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden group hover:shadow-xl transition-all duration-300 hover:shadow-purple-900/20">
      <div className="relative overflow-hidden">
        <img 
          src={artist.image} 
          alt={artist.name} 
          className="w-full aspect-[3/4] object-cover object-center transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent">
          {artist.featured && (
            <div className="absolute top-4 left-4">
              <span className="bg-purple-600 text-white text-xs font-medium px-2 py-1 rounded-sm">
                Featured
              </span>
            </div>
          )}
          
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <h3 className="text-white font-bold text-xl mb-1">{artist.name}</h3>
            <div className="flex flex-wrap gap-2 mb-3">
              {artist.genres.map((genre, index) => (
                <span key={index} className="text-gray-400 text-xs">
                  {genre}
                </span>
              ))}
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-gray-400 text-sm">
                <Disc className="h-4 w-4 mr-1" />
                <span>{artist.releases} releases</span>
              </div>
              
              <button className="text-purple-400 hover:text-white transition-colors">
                <Play className="h-5 w-5" fill="currentColor" />
              </button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <p className="text-gray-400 text-sm line-clamp-3">{artist.bio}</p>
        
        <div className="flex justify-between items-center mt-4">
          <Button 
            href="#" 
            variant="text" 
            size="small" 
            className="text-purple-400 hover:text-purple-300"
          >
            View Profile
          </Button>
          
          <div className="flex space-x-2">
            <SocialIcon href="https://instagram.com" />
            <SocialIcon href="https://spotify.com" />
          </div>
        </div>
      </div>
    </div>
  );
};

const SocialIcon = ({ href }: { href: string }) => {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-gray-400 hover:bg-purple-600 hover:text-white transition-all duration-300"
    >
      <ExternalLink className="h-4 w-4" />
    </a>
  );
};

// Sample data
const artists: Artist[] = [
  {
    name: "Skyler James",
    image: "https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg",
    genres: ["Alternative", "Indie", "Electronic"],
    featured: true,
    bio: "Skyler James blends indie sensibilities with electronic production, creating a unique sonic landscape that defies easy categorization.",
    releases: 8
  },
  {
    name: "The Electric Collective",
    image: "https://images.pexels.com/photos/167636/pexels-photo-167636.jpeg",
    genres: ["Electronic", "Synth", "Experimental"],
    featured: false,
    bio: "This innovative group of producers and instrumentalists creates immersive electronic soundscapes that push the boundaries of conventional music.",
    releases: 4
  },
  {
    name: "Aria Waves",
    image: "https://images.pexels.com/photos/1321909/pexels-photo-1321909.jpeg",
    genres: ["Ambient", "Downtempo", "Chill"],
    featured: false,
    bio: "Aria Waves crafts meditative ambient compositions that transport listeners to tranquil sonic environments, perfect for relaxation and focus.",
    releases: 6
  },
  {
    name: "Quantum Fields",
    image: "https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg",
    genres: ["IDM", "Experimental", "Electronic"],
    featured: false,
    bio: "A duo exploring the intersection of complex rhythms and atmospheric textures, creating an innovative sound that challenges and rewards the listener.",
    releases: 3
  },
  {
    name: "Jazz Nebula",
    image: "https://images.pexels.com/photos/3380743/pexels-photo-3380743.jpeg",
    genres: ["Jazz", "Fusion", "Electronic"],
    featured: false,
    bio: "Jazz Nebula brilliantly fuses traditional jazz instrumentation with modern electronic production techniques, creating a fresh approach to fusion.",
    releases: 5
  },
  {
    name: "Neon Pulse",
    image: "https://images.pexels.com/photos/1154189/pexels-photo-1154189.jpeg",
    genres: ["Synthwave", "Retrowave", "Electronic"],
    featured: false,
    bio: "Drawing inspiration from 80s aesthetics and sounds, Neon Pulse creates nostalgic yet futuristic electronic music that captivates listeners.",
    releases: 7
  }
];

export default ArtistsPage;