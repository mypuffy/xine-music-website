import React from 'react';
import { Link } from 'react-router-dom';

type ButtonProps = {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'text';
  size?: 'small' | 'medium' | 'large';
  href?: string;
  to?: string;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  icon?: React.ReactNode;
};

const Button = ({
  children,
  variant = 'primary',
  size = 'medium',
  href,
  to,
  className = '',
  onClick,
  disabled = false,
  type = 'button',
  icon,
}: ButtonProps) => {
  const baseStyles = 'inline-flex items-center justify-center transition-all duration-500 font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 relative overflow-hidden group';
  
  const variantStyles = {
    primary: 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white shadow-glow hover:shadow-glow-lg border border-purple-500/30',
    secondary: 'bg-gray-800/50 backdrop-blur-sm hover:bg-gray-700/50 text-white border border-gray-700/50 hover:border-purple-500/50',
    outline: 'border-2 border-purple-500 text-purple-400 hover:bg-purple-500/10 hover:text-purple-300 backdrop-blur-sm',
    text: 'text-purple-400 hover:text-purple-300 bg-transparent',
  };
  
  const sizeStyles = {
    small: 'text-xs px-3 py-1.5',
    medium: 'text-sm px-4 py-2',
    large: 'text-base px-6 py-3',
  };
  
  const disabledStyles = disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer';
  
  const buttonStyles = `${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${disabledStyles} ${className}`;

  const ButtonContent = () => (
    <>
      {/* Animated background for primary buttons */}
      {variant === 'primary' && (
        <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-blue-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      )}
      <span className="relative z-10 flex items-center">
        {icon && <span className="mr-2 group-hover:animate-pulse">{icon}</span>}
        {children}
      </span>
    </>
  );

  if (href) {
    return (
      <a href={href} className={buttonStyles} target="_blank" rel="noopener noreferrer">
        <ButtonContent />
      </a>
    );
  }

  if (to) {
    return (
      <Link to={to} className={buttonStyles}>
        <ButtonContent />
      </Link>
    );
  }

  return (
    <button
      type={type}
      className={buttonStyles}
      onClick={onClick}
      disabled={disabled}
    >
      <ButtonContent />
    </button>
  );
};

export default Button;