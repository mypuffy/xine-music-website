import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Music2, Menu, X } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled || isMenuOpen ? 'bg-gray-950/95 backdrop-blur-md py-3 border-b border-purple-500/20' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <Link
          to="/"
          className="flex items-center gap-2 text-2xl font-bold text-white group hover-glow"
        >
          <Music2 className="h-8 w-8 text-purple-500 group-hover:text-purple-400 transition-all duration-300 group-hover:animate-spin-slow" />
          <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent neon-glow">
            JSJ Music
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <NavLink key={link.path} to={link.path} label={link.label} />
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-white p-1 hover:text-purple-400 transition-colors duration-300"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-gray-950/95 backdrop-blur-md py-4 px-4 border-t border-purple-500/20 animate-slide-down">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <NavLink key={link.path} to={link.path} label={link.label} mobile />
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

const NavLink = ({ to, label, mobile = false }: { to: string; label: string; mobile?: boolean }) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={`relative font-medium transition-all duration-200 ${
        mobile ? 'text-lg py-2' : 'text-sm tracking-wide uppercase'
      } ${
        isActive
          ? 'text-purple-400 neon-glow'
          : 'text-white/80 hover:text-white hover:text-purple-300'
      }`}
    >
      {label}
      <span
        className={`absolute bottom-[-4px] left-0 w-full h-[2px] bg-gradient-to-r from-purple-500 to-blue-500 transform origin-left transition-transform duration-500 shadow-glow ${
          isActive ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
        }`}
      ></span>
    </Link>
  );
};

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/artists', label: 'Artists' },
  { path: '/releases', label: 'Releases' },
  { path: '/news', label: 'News' },
  { path: '/about', label: 'About' },
  { path: '/contact', label: 'Contact' },
];

export default Header;