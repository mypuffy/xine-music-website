import React from 'react';
import { Link } from 'react-router-dom';
import { Music2, Mail, Instagram, Twitter, Youtube, Facebook, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="dark-bg border-t border-purple-500/20 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-32 h-32 bg-purple-500 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute bottom-0 right-1/4 w-40 h-40 bg-blue-500 rounded-full blur-3xl animate-pulse-slow" style={{animationDelay: '2s'}}></div>
      </div>
      
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2 text-xl font-bold text-white hover-glow group">
              <Music2 className="h-7 w-7 text-purple-500 group-hover:animate-spin-slow transition-all duration-300" />
              <span className="bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent neon-glow">
                JSJ Music
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Pioneering the future of sound. JSJ Music is a forward-thinking label dedicated to pushing musical boundaries and discovering exceptional talent.
            </p>
            <div className="flex space-x-4 pt-2">
              <SocialIcon icon={<Instagram size={18} />} href="https://instagram.com" />
              <SocialIcon icon={<Twitter size={18} />} href="https://twitter.com" />
              <SocialIcon icon={<Youtube size={18} />} href="https://youtube.com" />
              <SocialIcon icon={<Facebook size={18} />} href="https://facebook.com" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-lg neon-glow">Quick Links</h4>
            <ul className="space-y-2">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link 
                    to={link.path} 
                    className="text-gray-400 hover:text-purple-400 transition-all duration-300 text-sm hover-lift"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Recent Releases */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-lg neon-glow">Recent Releases</h4>
            <ul className="space-y-3">
              {recentReleases.map((release, index) => (
                <li key={index}>
                  <Link to="/releases" className="text-gray-400 hover:text-purple-400 transition-all duration-300 text-sm flex items-start hover-lift">
                    <span className="inline-block w-3 h-3 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 mt-1.5 mr-2 animate-pulse-slow shadow-glow"></span>
                    {release}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-4 text-lg neon-glow">Contact Us</h4>
            <div className="space-y-3 text-sm">
              <p className="text-gray-400">
                Have questions or want to submit your demo? Get in touch with our team.
              </p>
              <Link to="/contact" className="inline-flex items-center text-purple-400 hover:text-purple-300 transition-all duration-300 hover-lift">
                <Mail size={16} className="mr-2" />
                info@jsjmusic.com
              </Link>
              <p className="text-gray-400 pt-2">
                Los Angeles, CA<br />
                United States
              </p>
            </div>
          </div>
        </div>

        <div className="pt-8 mt-8 border-t border-purple-500/20 text-center text-gray-500 text-sm">
          <p className="flex items-center justify-center gap-1">
            © {currentYear} JSJ Music. All rights reserved. Made with 
            <Heart size={14} className="text-red-500 inline animate-pulse" fill="currentColor" /> 
            for music.
          </p>
        </div>
      </div>
    </footer>
  );
};

const SocialIcon = ({ icon, href }: { icon: React.ReactNode; href: string }) => {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer" 
      className="w-8 h-8 rounded-full bg-gray-800/50 backdrop-blur-sm flex items-center justify-center text-gray-400 hover:bg-gradient-to-r hover:from-purple-500 hover:to-blue-500 hover:text-white transition-all duration-300 hover-glow border border-gray-700/50 hover:border-purple-500/50"
    >
      {icon}
    </a>
  );
};

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/artists', label: 'Artists' },
  { path: '/releases', label: 'Music' },
  { path: '/news', label: 'News' },
  { path: '/about', label: 'About Us' },
  { path: '/contact', label: 'Contact' },
];

const recentReleases = [
  "Midnight Dreams - EP by Luna Nova",
  "Echoes of Tomorrow - Single by Skyler James",
  "Neon Future - Album by The Electric Collective",
  "Resonance - Single by Aria Waves",
];

export default Footer;