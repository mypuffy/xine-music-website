'use client';

import React, { useEffect, useRef } from 'react';
import { Play, User, Disc, Calendar, ChevronRight, Zap, Activity, Radio } from 'lucide-react';
import Button from '@/components/ui/Button';
import Link from 'next/link';

const HomePage = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const createParticle = () => {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.width = Math.random() * 3 + 2 + 'px';
      particle.style.height = particle.style.width;
      particle.style.animationDelay = Math.random() * 15 + 's';
      particle.style.background = Math.random() > 0.5 ? 'rgba(6, 182, 212, 0.6)' : 'rgba(249, 115, 22, 0.6)';

      const particlesContainer = document.querySelector('.particles');
      if (particlesContainer) {
        particlesContainer.appendChild(particle);
        setTimeout(() => particle.remove(), 25000);
      }
    };

    const interval = setInterval(createParticle, 400);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col relative">
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="particles absolute inset-0 z-0"></div>

        <div className="absolute inset-0 cyber-grid opacity-30"></div>

        <div className="absolute inset-0 z-0">
          <div className="absolute top-20 left-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse-slow"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse-slow" style={{animationDelay: '2s'}}></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/5 rounded-full blur-3xl"></div>
        </div>

        <div className="absolute inset-0 z-5">
          <Zap className="absolute top-32 left-16 w-8 h-8 text-cyan-400/40 animate-float" style={{animationDelay: '0s'}} />
          <Activity className="absolute top-48 right-24 w-10 h-10 text-orange-400/40 animate-float" style={{animationDelay: '2s'}} />
          <Radio className="absolute bottom-48 left-32 w-7 h-7 text-cyan-400/40 animate-float" style={{animationDelay: '4s'}} />
          <Disc className="absolute top-72 left-1/3 w-6 h-6 text-orange-400/40 animate-float" style={{animationDelay: '1s'}} />
          <Zap className="absolute bottom-64 right-1/3 w-9 h-9 text-cyan-300/40 animate-float" style={{animationDelay: '3s'}} />
        </div>

        <div className="relative z-10 container mx-auto px-4 py-32 flex flex-col items-center text-center">
          <div className="mb-6 inline-flex items-center px-4 py-2 rounded-full glass-card">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse mr-3"></div>
            <span className="text-cyan-400 text-sm font-medium tracking-wider">LIVE FROM THE UNDERGROUND</span>
          </div>

          <div className="slide-in-up mb-8">
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-6 tracking-tighter">
              <span className="block text-white slide-in-up">HARD TECHNO</span>
              <span className="block bg-gradient-to-r from-cyan-400 via-blue-500 to-cyan-400 bg-clip-text text-transparent neon-glow slide-in-up" style={{animationDelay: '0.2s'}}>
                UNLEASHED
              </span>
            </h1>
          </div>

          <div className="slide-in-up max-w-3xl mb-12" style={{animationDelay: '0.3s'}}>
            <p className="text-gray-300 text-lg md:text-xl leading-relaxed">
              JSJ Music is pushing the boundaries of <span className="text-cyan-400 font-semibold">Hard Techno</span> and <span className="text-orange-400 font-semibold">Hardcore</span>.
              Experience the future of underground electronic music.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-5 mb-16 slide-in-up" style={{animationDelay: '0.4s'}}>
            <Button to="/releases" size="large" icon={<Play size={20} />} className="hover-glow">
              Explore Music
            </Button>
            <Button to="/artists" variant="outline" size="large" icon={<User size={20} />} className="hover-lift">
              Meet Artists
            </Button>
          </div>

          <div className="music-bars">
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
            <div className="music-bar"></div>
          </div>
        </div>

        <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce-slow">
          <a href="#releases" className="text-cyan-400/70 hover:text-cyan-400 transition-colors">
            <ChevronRight size={32} className="rotate-90" />
          </a>
        </div>
      </section>

      <section id="releases" className="py-32 dark-bg-secondary relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 30% 30%, rgba(6, 182, 212, 0.1) 0%, transparent 50%),
                             radial-gradient(circle at 70% 70%, rgba(249, 115, 22, 0.1) 0%, transparent 50%)`
          }}></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-center mb-16">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-0.5 bg-gradient-to-r from-transparent to-cyan-400"></div>
                <span className="text-cyan-400 text-sm font-semibold tracking-widest uppercase">Latest Drops</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white">
                Fresh <span className="text-cyan-400 neon-glow">Releases</span>
              </h2>
            </div>
            <Button to="/releases" variant="outline" icon={<ChevronRight size={18} />} className="hover-lift mt-6 md:mt-0">
              View All Releases
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {releases.map((release, index) => (
              <div key={index} className="slide-in-up" style={{animationDelay: `${index * 0.1}s`}}>
                <ReleaseCard release={release} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 dark-bg relative">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center mb-16">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-0.5 bg-gradient-to-r from-transparent to-orange-400"></div>
                <span className="text-orange-400 text-sm font-semibold tracking-widest uppercase">Our Roster</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white">
                Featured <span className="text-orange-400 neon-orange">Artists</span>
              </h2>
            </div>
            <Button to="/artists" variant="outline" icon={<ChevronRight size={18} />} className="hover-lift mt-6 md:mt-0">
              All Artists
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredArtists.map((artist, index) => (
              <div key={index} className="slide-in-up" style={{animationDelay: `${index * 0.15}s`}}>
                <ArtistCard artist={artist} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-32 dark-bg-secondary relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-500/5 rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="slide-in-left">
              <div className="relative group">
                <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-orange-500 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                <div className="relative aspect-square rounded-2xl overflow-hidden">
                  <img
                    src="https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg"
                    alt="JSJ Music Studios"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
                <div className="absolute -bottom-8 -right-8 glass-card p-8 rounded-2xl">
                  <p className="text-white text-center font-bold">
                    <span className="block text-5xl font-black bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">10+</span>
                    <span className="text-sm text-gray-400 uppercase tracking-wider">Years Active</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="slide-in-right">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-0.5 bg-gradient-to-r from-transparent to-cyan-400"></div>
                <span className="text-cyan-400 text-sm font-semibold tracking-widest uppercase">About Us</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-8">
                The Pulse of <span className="text-cyan-400 neon-glow">Underground</span>
              </h2>
              <div className="space-y-6 text-gray-300 text-lg leading-relaxed">
                <p>
                  Since 2015, <span className="text-cyan-400 font-semibold">JSJ Music</span> has been at the forefront of the Hard Techno revolution.
                  We don&apos;t just release music—we craft sonic experiences that shake the underground to its core.
                </p>
                <p>
                  From warehouse raves to festival main stages, our artists deliver relentless energy that moves crowds worldwide.
                  We discover raw talent and give them the platform to unleash their vision.
                </p>
              </div>
              <Button to="/about" variant="primary" className="hover-glow mt-10">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-black via-cyan-950/10 to-black"></div>
        <div className="absolute inset-0 cyber-grid opacity-20"></div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
            Ready to <span className="text-cyan-400 neon-glow">Join</span> the Movement?
          </h2>
          <p className="text-gray-300 text-xl max-w-3xl mx-auto mb-12 leading-relaxed">
            Whether you&apos;re a producer pushing boundaries or a fan of the underground scene,
            become part of the <span className="text-orange-400 font-semibold">JSJ Music</span> family.
          </p>
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <Button to="/contact" size="large" icon={<ChevronRight size={20} />} className="hover-glow">
              Submit Demo
            </Button>
            <Button to="/contact" variant="outline" size="large" className="hover-lift">
              Get in Touch
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

type Release = {
  title: string;
  artist: string;
  cover: string;
  type: string;
  releaseDate: string;
};

const ReleaseCard = ({ release }: { release: Release }) => {
  return (
    <div className="glass-card rounded-2xl overflow-hidden group hover-lift">
      <div className="relative overflow-hidden aspect-square">
        <img
          src={release.cover}
          alt={`${release.title} by ${release.artist}`}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
          <div className="bg-cyan-500 rounded-full p-4 transform scale-75 group-hover:scale-100 transition-transform duration-500 shadow-lg shadow-cyan-500/50">
            <Play className="h-8 w-8 text-black" fill="currentColor" />
          </div>
        </div>
        <div className="absolute top-3 right-3 bg-cyan-500/90 backdrop-blur-sm text-black text-xs font-bold px-3 py-1.5 rounded-full uppercase">
          {release.type}
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-white font-bold text-xl truncate mb-1">{release.title}</h3>
        <p className="text-cyan-400 text-sm font-medium mb-3">{release.artist}</p>
        <div className="flex items-center text-gray-400 text-xs">
          <Calendar className="h-3.5 w-3.5 mr-1.5" />
          {release.releaseDate}
        </div>
      </div>
    </div>
  );
};

type Artist = {
  name: string;
  image: string;
  genre: string;
};

const ArtistCard = ({ artist }: { artist: Artist }) => {
  return (
    <Link href="/artists" className="group block">
      <div className="relative overflow-hidden rounded-2xl glass-card hover-lift">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 to-orange-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
        <img
          src={artist.image}
          alt={artist.name}
          className="w-full aspect-[4/5] object-cover object-center transition-transform duration-1000 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent">
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="flex items-center mb-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 flex items-center justify-center mr-4 shadow-lg shadow-cyan-500/50">
                <User className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-white font-black text-2xl">{artist.name}</h3>
                <p className="text-cyan-300 text-sm font-medium">{artist.genre}</p>
              </div>
            </div>
            <div className="w-0 group-hover:w-full h-1 bg-gradient-to-r from-cyan-400 to-orange-400 transition-all duration-700 rounded-full shadow-lg shadow-cyan-400/50"></div>
          </div>
        </div>
      </div>
    </Link>
  );
};

const releases: Release[] = [
  {
    title: "Void Echoes",
    artist: "Zero Anima",
    cover: "https://images.pexels.com/photos/1626481/pexels-photo-1626481.jpeg",
    type: "EP",
    releaseDate: "May 15, 2025"
  },
  {
    title: "Hollow Frequencies",
    artist: "Nate Hollow",
    cover: "https://images.pexels.com/photos/167092/pexels-photo-167092.jpeg",
    type: "Single",
    releaseDate: "April 28, 2025"
  },
  {
    title: "Digital Daemon",
    artist: "Daemon Knox",
    cover: "https://images.pexels.com/photos/1389429/pexels-photo-1389429.jpeg",
    type: "Album",
    releaseDate: "April 10, 2025"
  },
  {
    title: "XiNE Protocol",
    artist: "XiNE",
    cover: "https://images.pexels.com/photos/1021876/pexels-photo-1021876.jpeg",
    type: "Single",
    releaseDate: "March 25, 2025"
  }
];

const featuredArtists: Artist[] = [
  {
    name: "Zero Anima",
    image: "https://images.pexels.com/photos/1699159/pexels-photo-1699159.jpeg",
    genre: "Hard Techno"
  },
  {
    name: "Nate Hollow",
    image: "https://images.pexels.com/photos/1270076/pexels-photo-1270076.jpeg",
    genre: "Hard Techno"
  },
  {
    name: "Daemon Knox",
    image: "https://images.pexels.com/photos/167636/pexels-photo-167636.jpeg",
    genre: "Hard Techno"
  }
];

export default HomePage;
