import React from 'react';
import Link from 'next/link';

type ButtonProps = {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'text';
  size?: 'small' | 'medium' | 'large';
  href?: string;
  to?: string;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  icon?: React.ReactNode;
};

const Button = ({
  children,
  variant = 'primary',
  size = 'medium',
  href,
  to,
  className = '',
  onClick,
  disabled = false,
  type = 'button',
  icon,
}: ButtonProps) => {
  const baseStyles = 'inline-flex items-center justify-center transition-all duration-300 font-semibold rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 relative overflow-hidden group';

  const variantStyles = {
    primary: 'bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black shadow-lg shadow-cyan-500/30 hover:shadow-cyan-500/50 border-0',
    secondary: 'bg-gray-900/50 backdrop-blur-sm hover:bg-gray-800/50 text-white border border-gray-700/50 hover:border-cyan-500/50',
    outline: 'border-2 border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 hover:text-cyan-300 backdrop-blur-sm hover:border-cyan-400',
    text: 'text-cyan-400 hover:text-cyan-300 bg-transparent',
  };

  const sizeStyles = {
    small: 'text-xs px-4 py-2',
    medium: 'text-sm px-6 py-3',
    large: 'text-base px-8 py-4',
  };

  const disabledStyles = disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer';

  const buttonStyles = `${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${disabledStyles} ${className}`;

  const ButtonContent = () => (
    <>
      {variant === 'primary' && (
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-300 to-blue-300 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
      )}
      <span className="relative z-10 flex items-center gap-2">
        {icon && <span className="group-hover:scale-110 transition-transform">{icon}</span>}
        {children}
      </span>
    </>
  );

  if (href) {
    return (
      <a href={href} className={buttonStyles} target="_blank" rel="noopener noreferrer">
        <ButtonContent />
      </a>
    );
  }

  if (to) {
    return (
      <Link href={to} className={buttonStyles}>
        <ButtonContent />
      </Link>
    );
  }

  return (
    <button
      type={type}
      className={buttonStyles}
      onClick={onClick}
      disabled={disabled}
    >
      <ButtonContent />
    </button>
  );
};

export default Button;
