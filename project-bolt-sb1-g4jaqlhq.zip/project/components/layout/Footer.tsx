import React from 'react';
import Link from 'next/link';
import { Music2, Mail, Instagram, Twitter, Youtube, Facebook, Heart } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="dark-bg border-t border-cyan-500/20 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-32 h-32 bg-cyan-500 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute bottom-0 right-1/4 w-40 h-40 bg-orange-500 rounded-full blur-3xl animate-pulse-slow" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="space-y-5">
            <Link href="/" className="flex items-center gap-3 text-xl font-black text-white group">
              <Music2 className="h-8 w-8 text-cyan-400 group-hover:rotate-12 transition-all duration-300" />
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent neon-glow">
                JSJ Music
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed">
              Unleashing uncompromising Hard Techno and Hardcore. JSJ Music is a forward-thinking label dedicated to pushing sonic limits and discovering exceptional underground talent.
            </p>
            <div className="flex space-x-4 pt-2">
              <SocialIcon icon={<Instagram size={18} />} href="https://instagram.com" />
              <SocialIcon icon={<Twitter size={18} />} href="https://twitter.com" />
              <SocialIcon icon={<Youtube size={18} />} href="https://youtube.com" />
              <SocialIcon icon={<Facebook size={18} />} href="https://facebook.com" />
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-5 text-lg">Quick Links</h4>
            <ul className="space-y-3">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    href={link.path}
                    className="text-gray-400 hover:text-cyan-400 transition-all duration-300 text-sm inline-flex items-center group"
                  >
                    <span className="w-0 group-hover:w-2 h-0.5 bg-cyan-400 mr-0 group-hover:mr-2 transition-all duration-300"></span>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-5 text-lg">Recent Releases</h4>
            <ul className="space-y-3">
              {recentReleases.map((release, index) => (
                <li key={index}>
                  <Link href="/releases" className="text-gray-400 hover:text-cyan-400 transition-all duration-300 text-sm flex items-start group">
                    <span className="inline-block w-2 h-2 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 mt-1.5 mr-3 animate-pulse shadow-lg shadow-cyan-400/50"></span>
                    <span className="group-hover:translate-x-1 transition-transform duration-300">{release}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-5 text-lg">Contact Us</h4>
            <div className="space-y-4 text-sm">
              <p className="text-gray-400 leading-relaxed">
                Questions or demo submission? Get in touch with our team.
              </p>
              <Link href="/contact" className="inline-flex items-center text-cyan-400 hover:text-cyan-300 transition-all duration-300 group">
                <Mail size={16} className="mr-2 group-hover:translate-x-1 transition-transform" />
                info@jsjmusic.com
              </Link>
              <p className="text-gray-400 pt-2">
                Los Angeles, CA<br />
                United States
              </p>
            </div>
          </div>
        </div>

        <div className="pt-10 mt-10 border-t border-cyan-500/10 text-center text-gray-500 text-sm">
          <p className="flex items-center justify-center gap-2">
            © {currentYear} JSJ Music. All rights reserved. Made with
            <Heart size={14} className="text-cyan-400 inline animate-pulse" fill="currentColor" />
            for the underground.
          </p>
        </div>
      </div>
    </footer>
  );
};

const SocialIcon = ({ icon, href }: { icon: React.ReactNode; href: string }) => {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="w-10 h-10 rounded-full glass-card flex items-center justify-center text-gray-400 hover:text-cyan-400 transition-all duration-300 border border-gray-800/50 hover:border-cyan-500/50 hover:shadow-lg hover:shadow-cyan-500/30 hover:scale-110"
    >
      {icon}
    </a>
  );
};

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/artists', label: 'Artists' },
  { path: '/releases', label: 'Music' },
  { path: '/news', label: 'News' },
  { path: '/about', label: 'About Us' },
  { path: '/contact', label: 'Contact' },
];

const recentReleases = [
  "Void Echoes - EP by Zero Anima",
  "Hollow Frequencies - Single by Nate Hollow",
  "Digital Daemon - Album by Daemon Knox",
  "XiNE Protocol - Single by XiNE",
];

export default Footer;
