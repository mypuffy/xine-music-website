'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Music2, Menu, X } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [pathname]);

  return (
    <header
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled || isMenuOpen ? 'glass-card py-3 border-b border-cyan-500/20' : 'bg-transparent py-5'
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
        <Link
          href="/"
          className="flex items-center gap-3 text-2xl font-black text-white group"
        >
          <Music2 className="h-8 w-8 text-cyan-400 group-hover:text-cyan-300 transition-all duration-300 group-hover:rotate-12" />
          <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent neon-glow tracking-tight">
            JSJ Music
          </span>
        </Link>

        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <NavLink key={link.path} href={link.path} label={link.label} />
          ))}
        </nav>

        <button
          className="md:hidden text-white p-1 hover:text-cyan-400 transition-colors duration-300"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMenuOpen && (
        <div className="md:hidden absolute top-full left-0 w-full glass-card py-6 px-4 border-t border-cyan-500/20 animate-slide-down">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <NavLink key={link.path} href={link.path} label={link.label} mobile />
            ))}
          </nav>
        </div>
      )}
    </header>
  );
};

const NavLink = ({ href, label, mobile = false }: { href: string; label: string; mobile?: boolean }) => {
  const pathname = usePathname();
  const isActive = pathname === href;

  return (
    <Link
      href={href}
      className={`relative font-semibold transition-all duration-200 group ${
        mobile ? 'text-lg py-2' : 'text-sm tracking-wider uppercase'
      } ${
        isActive
          ? 'text-cyan-400 neon-glow'
          : 'text-gray-300 hover:text-white'
      }`}
    >
      {label}
      {!mobile && (
        <span
          className={`absolute bottom-[-4px] left-0 w-full h-[2px] bg-gradient-to-r from-cyan-400 to-blue-500 transform origin-left transition-transform duration-300 ${
            isActive ? 'scale-x-100 shadow-lg shadow-cyan-400/50' : 'scale-x-0 group-hover:scale-x-100'
          }`}
        ></span>
      )}
    </Link>
  );
};

const navLinks = [
  { path: '/', label: 'Home' },
  { path: '/artists', label: 'Artists' },
  { path: '/releases', label: 'Releases' },
  { path: '/news', label: 'News' },
  { path: '/about', label: 'About' },
  { path: '/contact', label: 'Contact' },
];

export default Header;
