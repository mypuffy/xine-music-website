import React from 'react';

interface LogoProps {
  className?: string;
}

export const NateHollowLogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="nate-grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#1a1a2e" />
        <stop offset="100%" stopColor="#0f0f1a" />
      </linearGradient>
      <filter id="nate-glow">
        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#nate-grad)" />
    <g transform="translate(200, 200)" filter="url(#nate-glow)">
      <circle r="120" fill="none" stroke="#e63946" strokeWidth="2" opacity="0.3" />
      <circle r="90" fill="none" stroke="#e63946" strokeWidth="1" opacity="0.5" />
      <circle r="60" fill="none" stroke="#e63946" strokeWidth="3" />
      <path d="M-40,-60 L-40,60 M-40,-60 L40,60 L40,-60" fill="none" stroke="#ffffff" strokeWidth="8" strokeLinecap="round" />
      <path d="M-25,80 L-25,100 L25,100 L25,80" fill="none" stroke="#e63946" strokeWidth="3" />
    </g>
    <text x="200" y="340" textAnchor="middle" fill="#ffffff" fontSize="24" fontFamily="monospace" letterSpacing="8">NATE HOLLOW</text>
  </svg>
);

export const DaemonKnoxLogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="daemon-grad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#1a1a1a" />
        <stop offset="100%" stopColor="#000000" />
      </linearGradient>
      <filter id="daemon-glow">
        <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#daemon-grad)" />
    <g transform="translate(200, 180)">
      <polygon points="0,-100 87,-50 87,50 0,100 -87,50 -87,-50" fill="none" stroke="#dc2626" strokeWidth="3" filter="url(#daemon-glow)" />
      <polygon points="0,-70 60,-35 60,35 0,70 -60,35 -60,-35" fill="none" stroke="#991b1b" strokeWidth="2" />
      <path d="M-30,-20 L-30,30 Q-30,40 -20,40 L20,40 Q30,40 30,30 L30,-20" fill="none" stroke="#ffffff" strokeWidth="6" strokeLinecap="round" />
      <line x1="-30" y1="10" x2="0" y2="10" stroke="#ffffff" strokeWidth="6" strokeLinecap="round" />
      <circle cx="0" cy="0" r="8" fill="#dc2626" />
    </g>
    <text x="200" y="320" textAnchor="middle" fill="#dc2626" fontSize="28" fontFamily="monospace" fontWeight="bold" letterSpacing="4">DAEMON</text>
    <text x="200" y="355" textAnchor="middle" fill="#ffffff" fontSize="22" fontFamily="monospace" letterSpacing="10">KNOX</text>
  </svg>
);

export const XiNELogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="xine-grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0a0a0f" />
        <stop offset="50%" stopColor="#0d1117" />
        <stop offset="100%" stopColor="#0a0a0f" />
      </linearGradient>
      <filter id="xine-neon">
        <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#xine-grad)" />
    <g transform="translate(200, 200)" filter="url(#xine-neon)">
      <rect x="-100" y="-100" width="200" height="200" fill="none" stroke="#06b6d4" strokeWidth="2" transform="rotate(45)" />
      <rect x="-70" y="-70" width="140" height="140" fill="none" stroke="#0891b2" strokeWidth="1" transform="rotate(45)" />
      <text x="0" y="15" textAnchor="middle" fill="#06b6d4" fontSize="72" fontFamily="monospace" fontWeight="bold">Xi</text>
      <text x="0" y="15" textAnchor="middle" fill="none" stroke="#ffffff" strokeWidth="1" fontSize="72" fontFamily="monospace" fontWeight="bold">Xi</text>
      <text x="0" y="70" textAnchor="middle" fill="#ffffff" fontSize="48" fontFamily="monospace" fontWeight="bold" letterSpacing="12">NE</text>
    </g>
    <line x1="50" y1="380" x2="350" y2="380" stroke="#06b6d4" strokeWidth="2" />
    <line x1="50" y1="20" x2="350" y2="20" stroke="#06b6d4" strokeWidth="2" />
  </svg>
);

export const ThreeTimesXLogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="3x-grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0f0f0f" />
        <stop offset="100%" stopColor="#1a0a0a" />
      </linearGradient>
      <filter id="3x-glitch">
        <feGaussianBlur stdDeviation="1" result="blur"/>
        <feMerge>
          <feMergeNode in="blur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#3x-grad)" />
    <g transform="translate(200, 180)">
      <text x="-2" y="0" textAnchor="middle" fill="#ff0040" fontSize="100" fontFamily="monospace" fontWeight="bold" opacity="0.5">3</text>
      <text x="2" y="0" textAnchor="middle" fill="#00ffff" fontSize="100" fontFamily="monospace" fontWeight="bold" opacity="0.5">3</text>
      <text x="0" y="0" textAnchor="middle" fill="#ffffff" fontSize="100" fontFamily="monospace" fontWeight="bold">3</text>
      <text x="0" y="60" textAnchor="middle" fill="#ff0040" fontSize="36" fontFamily="monospace" fontWeight="bold" filter="url(#3x-glitch)">TiMES</text>
      <text x="-3" y="100" textAnchor="middle" fill="#00ffff" fontSize="64" fontFamily="monospace" fontWeight="bold" opacity="0.7">!X</text>
      <text x="3" y="100" textAnchor="middle" fill="#ff0040" fontSize="64" fontFamily="monospace" fontWeight="bold" opacity="0.7">!X</text>
      <text x="0" y="100" textAnchor="middle" fill="#ffffff" fontSize="64" fontFamily="monospace" fontWeight="bold">!X</text>
    </g>
    <line x1="30" y1="50" x2="120" y2="50" stroke="#ff0040" strokeWidth="3" />
    <line x1="280" y1="350" x2="370" y2="350" stroke="#00ffff" strokeWidth="3" />
    <rect x="340" y="40" width="30" height="30" fill="none" stroke="#ff0040" strokeWidth="2" />
    <rect x="30" y="330" width="30" height="30" fill="none" stroke="#00ffff" strokeWidth="2" />
  </svg>
);

export const ZeroAnimaLogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="zero-grad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#0a0a0a" />
        <stop offset="100%" stopColor="#1a1a1a" />
      </linearGradient>
      <filter id="zero-glow">
        <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#zero-grad)" />
    <g transform="translate(200, 170)" filter="url(#zero-glow)">
      <ellipse cx="0" cy="0" rx="80" ry="100" fill="none" stroke="#22c55e" strokeWidth="6" />
      <ellipse cx="0" cy="0" rx="50" ry="70" fill="none" stroke="#15803d" strokeWidth="2" />
      <ellipse cx="0" cy="0" rx="20" ry="30" fill="none" stroke="#22c55e" strokeWidth="1" />
      <circle cx="0" cy="0" r="5" fill="#22c55e" />
      <line x1="-100" y1="0" x2="-85" y2="0" stroke="#22c55e" strokeWidth="2" />
      <line x1="85" y1="0" x2="100" y2="0" stroke="#22c55e" strokeWidth="2" />
      <line x1="0" y1="-115" x2="0" y2="-105" stroke="#22c55e" strokeWidth="2" />
      <line x1="0" y1="105" x2="0" y2="115" stroke="#22c55e" strokeWidth="2" />
    </g>
    <text x="200" y="320" textAnchor="middle" fill="#22c55e" fontSize="18" fontFamily="monospace" letterSpacing="2">ZERO</text>
    <text x="200" y="355" textAnchor="middle" fill="#ffffff" fontSize="32" fontFamily="monospace" fontWeight="bold" letterSpacing="8">ANIMA</text>
  </svg>
);

export const LunaNovaLogo: React.FC<LogoProps> = ({ className = '' }) => (
  <svg viewBox="0 0 400 400" className={className} xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="luna-grad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#0a0a1a" />
        <stop offset="100%" stopColor="#1a0a2a" />
      </linearGradient>
      <radialGradient id="luna-moon" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#fbbf24" />
        <stop offset="100%" stopColor="#d97706" />
      </radialGradient>
      <filter id="luna-glow">
        <feGaussianBlur stdDeviation="8" result="coloredBlur"/>
        <feMerge>
          <feMergeNode in="coloredBlur"/>
          <feMergeNode in="SourceGraphic"/>
        </feMerge>
      </filter>
    </defs>
    <rect width="400" height="400" fill="url(#luna-grad)" />
    <g transform="translate(200, 160)">
      <circle cx="0" cy="0" r="70" fill="url(#luna-moon)" filter="url(#luna-glow)" />
      <circle cx="25" cy="0" r="55" fill="url(#luna-grad)" />
      <circle cx="-30" cy="-20" r="3" fill="#fbbf24" opacity="0.8" />
      <circle cx="80" cy="-60" r="2" fill="#ffffff" opacity="0.6" />
      <circle cx="-90" cy="30" r="2" fill="#ffffff" opacity="0.7" />
      <circle cx="60" cy="80" r="1.5" fill="#ffffff" opacity="0.5" />
      <circle cx="-70" cy="-70" r="2.5" fill="#ffffff" opacity="0.8" />
      <circle cx="100" cy="20" r="1" fill="#fbbf24" opacity="0.6" />
    </g>
    <text x="200" y="290" textAnchor="middle" fill="#fbbf24" fontSize="36" fontFamily="serif" fontStyle="italic" letterSpacing="4">Luna</text>
    <text x="200" y="340" textAnchor="middle" fill="#ffffff" fontSize="28" fontFamily="monospace" fontWeight="bold" letterSpacing="12">NOVA</text>
  </svg>
);

export const artistLogos: Record<string, React.FC<LogoProps>> = {
  'Nate Hollow': NateHollowLogo,
  'Daemon Knox': DaemonKnoxLogo,
  'XiNE': XiNELogo,
  '3TiMES!X': ThreeTimesXLogo,
  'Zero Anima': ZeroAnimaLogo,
  'Luna Nova': LunaNovaLogo,
};
