import React from 'react'
import { Link } from 'react-router-dom'
import { Music } from 'lucide-react'

const Header = () => {
  const [isOpen, setIsOpen] = React.useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/30 backdrop-blur-md border-b border-cyan-500/20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center shadow-lg shadow-cyan-500/50 group-hover:shadow-cyan-500/70 transition-shadow">
            <Music className="w-6 h-6 text-black" />
          </div>
          <span className="text-white font-black text-xl hidden sm:inline">JSJ</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <Link to="/" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium">Home</Link>
          <Link to="/releases" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium">Releases</Link>
          <Link to="/artists" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium">Artists</Link>
          <Link to="/about" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium">About</Link>
          <Link to="/contact" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium">Contact</Link>
        </nav>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-cyan-400 hover:text-cyan-300"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
          </svg>
        </button>

        {isOpen && (
          <nav className="absolute top-full left-0 right-0 bg-black/95 backdrop-blur-md border-b border-cyan-500/20 md:hidden flex flex-col gap-4 p-4">
            <Link to="/" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium" onClick={() => setIsOpen(false)}>Home</Link>
            <Link to="/releases" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium" onClick={() => setIsOpen(false)}>Releases</Link>
            <Link to="/artists" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium" onClick={() => setIsOpen(false)}>Artists</Link>
            <Link to="/about" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium" onClick={() => setIsOpen(false)}>About</Link>
            <Link to="/contact" className="text-gray-300 hover:text-cyan-400 transition-colors font-medium" onClick={() => setIsOpen(false)}>Contact</Link>
          </nav>
        )}
      </div>
    </header>
  )
}

export default Header
