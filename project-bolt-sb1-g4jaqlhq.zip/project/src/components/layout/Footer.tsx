import React from 'react'
import { Link } from 'react-router-dom'
import { Mail, MapPin, Phone } from 'lucide-react'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-black/50 backdrop-blur-md border-t border-cyan-500/20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-white font-bold text-lg mb-4">JSJ Music</h3>
            <p className="text-gray-400 text-sm">
              Pushing the boundaries of Hard Techno and underground electronic music.
            </p>
          </div>

          <div>
            <h4 className="text-cyan-400 font-semibold mb-4">Navigation</h4>
            <nav className="space-y-2">
              <Link to="/" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Home</Link>
              <Link to="/releases" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Releases</Link>
              <Link to="/artists" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">Artists</Link>
              <Link to="/about" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm">About</Link>
            </nav>
          </div>

          <div>
            <h4 className="text-cyan-400 font-semibold mb-4">Contact</h4>
            <div className="space-y-3">
              <a href="mailto:info@jsjmusic.com" className="flex items-center gap-2 text-gray-400 hover:text-cyan-400 transition-colors text-sm">
                <Mail className="w-4 h-4" />
                info@jsjmusic.com
              </a>
              <div className="flex items-center gap-2 text-gray-400 text-sm">
                <MapPin className="w-4 h-4" />
                Underground, Global
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-cyan-400 font-semibold mb-4">Social</h4>
            <div className="space-y-2">
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm block">Spotify</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm block">SoundCloud</a>
              <a href="#" className="text-gray-400 hover:text-cyan-400 transition-colors text-sm block">Instagram</a>
            </div>
          </div>
        </div>

        <div className="border-t border-cyan-500/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {currentYear} JSJ Music. All rights reserved.
          </p>
          <div className="flex gap-6 mt-4 md:mt-0 text-sm">
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors">Privacy</a>
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors">Terms</a>
            <a href="#" className="text-gray-500 hover:text-cyan-400 transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer
