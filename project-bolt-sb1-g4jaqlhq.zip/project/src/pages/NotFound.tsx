import React from 'react'
import { useNavigate } from 'react-router-dom'
import Button from '@/components/ui/Button'
import { ChevronLeft } from 'lucide-react'

const NotFound = () => {
  const navigate = useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center bg-black relative overflow-hidden pt-20">
      <div className="absolute inset-0 z-0">
        <div className="absolute top-20 left-20 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse-slow" style={{animationDelay: '2s'}}></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center">
        <h1 className="text-8xl font-black text-white mb-4">404</h1>
        <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
          Page Not <span className="text-cyan-400 neon-glow">Found</span>
        </h2>
        <p className="text-gray-300 text-xl max-w-2xl mx-auto mb-12">
          The page you're looking for has vanished into the digital void.
        </p>
        <div className="flex flex-col sm:flex-row gap-5 justify-center">
          <Button to="/" icon={<ChevronLeft size={20} />} className="hover-glow">
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  )
}

export default NotFound
